
<?php $__env->startSection('page_title','ISME | Home'); ?>
<?php $__env->startSection('page_css'); ?>
 <!-- <link href="<?php echo e(asset('themes/frontend')); ?>/css/modal-video.min.css" rel="stylesheet"> -->
 <link href="<?php echo e(asset('themes/frontend')); ?>/css/YouTubePopUp.css" rel="stylesheet">
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="banner-section">
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img class="hidden-xs img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/banner-1.png" alt="Banner">
      <img class="img-100 hidden-sm hidden-md hidden-lg" src="<?php echo e(asset('themes/frontend')); ?>/images/mobile-banner.png">
       <div class="carousel-caption">
        <h3>Learn to lead</h3>
        <div class="clearfix"></div>

        <p>Programmes designed for entrepreneual</p>
        <div class="clearfix"></div>
         <p> leaders</p>
      </div>
    </div>

    <div class="item">
     <img class="hidden-xs img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/banner-1.png" alt="Banner">
      <img class="img-100 hidden-sm hidden-md hidden-lg" src="<?php echo e(asset('themes/frontend')); ?>/images/mobile-banner.png">
      <div class="carousel-caption">
        <h3>Learn to lead</h3>
        <div class="clearfix"></div>
         <p>Programmes designed for entrepreneual</p>
         <div class="clearfix"></div>
         <p> leaders</p>
      </div>
    </div>

    <div class="item">
     <img class="hidden-xs img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/banner-1.png" alt="Banner">
      <img class="img-100 hidden-sm hidden-md hidden-lg" src="<?php echo e(asset('themes/frontend')); ?>/images/mobile-banner.png">
      <div class="carousel-caption">
        <h3>Learn to lead</h3>
        <div class="clearfix"></div>
         <p>Programmes designed for entrepreneual</p>
         <div class="clearfix"></div>
         <p> leaders</p>
      </div>
    </div>
  </div>

  <!-- Left and right controls -->
  <!-- <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a> -->
</div>
 <div class="scroll-down hidden-xs">
    <div class="scroll-down-img">
      <img src="<?php echo e(asset('themes/frontend')); ?>/images/scroll-down.png" class="img-responsive center-block">
    </div>
  </div>
</section>
<div id="page-scrl">
<a class="get-in-touch-btn hidden-xs page-scroll" href="#getintouch">Get in touch</a>
</div>
   <section class="welcome-section">
       <div class="container">
        <div class="strip hidden-xs">
      <img src="<?php echo e(asset('themes/frontend')); ?>/images/strip.png" class="img-responsive center-block">
    </div>
        <div class="row">
            <div class="col-lg-6 col-sm-7">
              <h2>Welcome to isme</h2>
              <div class="welcome-text-wrapper">
              <h4><b>Dr. indu shahani</b><br>
                 chair academic council, <br>
                 isdi & isme</h4>
                 <p>The spirit of ISME is infectious, innovative and exciting. There is a wave of entrepreneurial initiatives and innovation in India. There is a positive energy that is both nurturing and inspiring for students. The current atmosphere is of Entrepreneurship, Innovation and Excitement.</p>
                 <span>Write to the Chairperson</span><a href="mail-to:"><i class="fa fa-envelope fa-envelope-cls"></i></a>

                 <div class="vision-message-wrap"><span>Chairperson's Message</span><span class="vision-text">Vision & Misson</span></div>
                 <a class="know-more">Know More <img  src="<?php echo e(asset('themes/frontend')); ?>/images/right-arrow.png" class="img-responsive arrow-img"></i></a>
               </div>
            </div>
            <div class="col-lg-5 col-lg-offset-1 col-sm-5">
               <img  src="<?php echo e(asset('themes/frontend')); ?>/images/welcome-img.png" class="img-responsive mob-img-padding">
            </div>
        </div>
       </div>
   </section>
 <section class="program-section">
  <div class="container">
    <h2>Programs</h2>
    <div class="row">
       <div class="col-sm-6 col-xs-12">
        <img src="<?php echo e(asset('themes/frontend')); ?>/images/program-1.png" class="img-responsive program-img">
        <div class="program-text-wrapper">
          <h3>Business Management and Entrepreneurship (BME) - Redefining Undergraduate Studies</h3>
          <a class="know-more">Know More <img  src="<?php echo e(asset('themes/frontend')); ?>/images/arrow-2.png" class="img-responsive arrow-img"></i></a>
        </div>
       </div>
       <div class="col-sm-6 col-xs-12">
         <img src="<?php echo e(asset('themes/frontend')); ?>/images/program-2.png" class="img-responsive">
         <div class="program-text-wrapper">
          <h3>Post Graduate Program in Management, Business & Entrepreneurship (MBE)</h3>
          <a class="know-more">Know More <img  src="<?php echo e(asset('themes/frontend')); ?>/images/arrow-2.png" class="img-responsive arrow-img"></i></a>
        </div>
       </div>
    </div>
  </div>
 </section>
   <section class="event-section">
   <div class="container">
     <h2>Events</h2>
      <div class="slider1 video-slider">
      <div class="col-sm-4">
        <a class="vid-1" href="https://www.youtube.com/watch?v=2BSKLrvbZQc">
        <img  src="<?php echo e(asset('themes/frontend')); ?>/images/thumb-1.png" class="img-responsive"> 
       
       </a>
       </div>
       <div class="col-sm-4">
        <a class="vid-2" href="https://www.youtube.com/watch?v=rOakCTBqpxc">
        <img  src="<?php echo e(asset('themes/frontend')); ?>/images/thumb-2.png" class="img-responsive">
       </a>
       </div>
       <div class="col-sm-4">
        <a class="vid-3" href="https://www.youtube.com/watch?v=qCI59OnxElw">
        <img  src="<?php echo e(asset('themes/frontend')); ?>/images/thumb-3.png" class="img-responsive">
       </a>
       </div>
       <div class="col-sm-4">
        <a class="vid-4" href="https://www.youtube.com/watch?v=tR0yp031TlA">
        <img  src="<?php echo e(asset('themes/frontend')); ?>/images/thumb-4.png" class="img-responsive">
       </a>
       </div>
       <div class="col-sm-4">
        <a class="vid-5" href="https://www.youtube.com/watch?v=nrEqDMH5Vr4">
        <img  src="<?php echo e(asset('themes/frontend')); ?>/images/thumb-5.png" class="img-responsive">
       </a>
       </div>
       <div class="col-sm-4">
        <a class="vid-6" href="https://www.youtube.com/watch?v=mh9H5Dqu4ao">
        <img  src="<?php echo e(asset('themes/frontend')); ?>/images/thumb-6.png" class="img-responsive">
       </a>
       </div>
      
         
     </div>
   </div>
 </section> 

<section class="faculty-section">
  <div class="container">
    <h2>Faculty</h2>
    <div class="row">
      <div class="col-sm-6 col-pad-0">
        <div class="faculty-block">
          <img  src="<?php echo e(asset('themes/frontend')); ?>/images/indu-shahani.png" class="img-responsive faculty-img">
          <div class="faculty-block-text">
            <div class="heading">
              <h3>DR. INDU SHAHANI</h3>
              <a class="know-more">Dean at ISME  <img  src="<?php echo e(asset('themes/frontend')); ?>/images/right-arrow.png" class="img-responsive arrow-img"></i></a>
            </div>
            <div class="desc">
               <h3>DR. INDU SHAHANI</h3>
              <p>Founding Dean ISME & Chairperson at ISDI, ISDI |WPP & ISME is the driving....</p>
              <a class="know-more">View More  <img  src="<?php echo e(asset('themes/frontend')); ?>/images/arrow-2.png" class="img-responsive arrow-img"></i></a>
            </div>
            
          </div>
        </div>
      </div>
       <div class="col-sm-6 col-pad-0">
        <div class="faculty-block">
          <img  src="<?php echo e(asset('themes/frontend')); ?>/images/mukesh-patel.png" class="img-responsive faculty-img">
          <div class="faculty-block-text">
            <div class="heading">
              <h3>Mookesh patel</h3>
              <a class="know-more">Dean at ISDI  <img  src="<?php echo e(asset('themes/frontend')); ?>/images/right-arrow.png" class="img-responsive arrow-img"></i></a>
            </div>
            <div class="desc">
              <h3>Mookesh patel</h3>
              <p>Dean at ISDI is popularly known amongst students as their ‘favorite dean’....</p>
              <a class="know-more">View More  <img  src="<?php echo e(asset('themes/frontend')); ?>/images/arrow-2.png" class="img-responsive arrow-img"></i></a>
            </div>
            
          </div>
        </div>
      </div>
    </div>

     <div class="row">
      <div class="col-sm-6 col-pad-0 second-faculty-block">
        <div class="faculty-block">
        <div class="faculty-block-text">
            <div class="heading">
              <h3>chandan chatterjee</h3>
              <a class="know-more">Has 24 years of experience <br> in the industry.  <img  src="<?php echo e(asset('themes/frontend')); ?>/images/right-arrow.png" class="img-responsive "></i></a>
            </div>
            <div class="desc">
              <h3>chandan chatterjee</h3>
              <p>Has 24 years of experience in the industry, 10 years of experience in education ....</p>
               <a class="know-more">View More  <img  src="<?php echo e(asset('themes/frontend')); ?>/images/arrow-2.png" class="img-responsive arrow-img"></i></a>
            </div>
            
          </div>
           <img  src="<?php echo e(asset('themes/frontend')); ?>/images/chandan-chaterjee.png" class="img-responsive flt-right faculty-img">
        </div>
      </div>
      <div class="col-sm-6 col-pad-0 second-faculty-block">
        <div class="faculty-block">
        <div class="faculty-block-text">
            <div class="heading">
              <h3>Meena Desai</h3>
              <a class="know-more">Program Director at ISME  <img  src="<?php echo e(asset('themes/frontend')); ?>/images/right-arrow.png" class="img-responsive "></i></a>
            </div>
            <div class="desc">
              <h3>Meena Desai</h3>
              <p>Program Director at ISME,she has been a project guide and...</p>
               <a class="know-more">View More  <img  src="<?php echo e(asset('themes/frontend')); ?>/images/arrow-2.png" class="img-responsive arrow-img"></i></a>
            </div>
            
          </div>
           <img  src="<?php echo e(asset('themes/frontend')); ?>/images/meena-desai.png" class="img-responsive flt-right faculty-img">
        </div>
      </div>
    </div>

  </div>
</section> 

 <section class="partner-section">
   <div class="container">
      <h2> Partner schools</h2>
         <div class="slider partner-slider">
      <div>
        <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-1.png" />
      </div>
      <div>
        <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-2.png" />
      </div>
      <div>
        <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-3.png" />
      </div>
      <div>
        <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-4.png" />
      </div>
      <div>
        <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-1.png" />
      </div>
      <div>
        <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-2.png" />
      </div>
    </div>
       </div>
 </section> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_script'); ?>
<script type="text/javascript" src="<?php echo e(asset('themes/frontend')); ?>/js/YouTubePopUp.jquery.js"></script>
  <script type="text/javascript">
    jQuery(function(){
      jQuery("a.vid-1").YouTubePopUp();
      jQuery("a.vid-2").YouTubePopUp(); // Disable autoplay
      jQuery("a.vid-3").YouTubePopUp();
      jQuery("a.vid-4").YouTubePopUp();
      jQuery("a.vid-5").YouTubePopUp();
      jQuery("a.vid-6").YouTubePopUp();
    });
  </script>

  <script type="text/javascript">

    jQuery(document).on('ready', function() {

       $window = jQuery( window ).width();

      if($window<=767){

        jQuery(".partner-slider").slick({

        dots: false,

        infinite: true,

        slidesToShow: 1,

        slidesToScroll: 1,

        autoplay: false

      });

      }else if($window<=991){

         jQuery(".partner-slider").slick({

        dots: false,

        infinite: true,

        slidesToShow: 3,

        slidesToScroll: 3,

        autoplay: true

      });

      }else{

        jQuery(".partner-slider").slick({

        dots: false,

        infinite: false,

        slidesToShow: 4,

        slidesToScroll: 1,

        autoplay: true

      });

      }

      

    });

  </script>
   <script type="text/javascript">

    jQuery(document).on('ready', function() {

       $window = jQuery( window ).width();

      if($window<=767){

        jQuery(".video-slider").slick({

        dots: false,

        infinite: true,

        slidesToShow: 1,

        slidesToScroll: 1,

        autoplay: false

      });

      }else if($window<=991){

         jQuery(".video-slider").slick({

        dots: false,

        infinite: true,

        slidesToShow: 3,

        slidesToScroll: 3,

        autoplay: true

      });

      }else{

        jQuery(".video-slider").slick({

        dots: false,

        infinite: false,

        slidesToShow: 4,

        slidesToScroll: 1,

        autoplay: true

      });

      }

      

    });

  </script>
  
  
  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>