<!doctypt html>
<html>
   <head>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('page_title'); ?></title>
      <link rel="stylesheet" href="<?php echo e(asset('themes/frontend')); ?>/css/bootstrap.css">
      <link rel="stylesheet" href="<?php echo e(asset('themes/frontend')); ?>/css/custom.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
       <link rel="stylesheet" href="<?php echo e(asset('themes/frontend')); ?>/css/slick.css">
      <link rel="stylesheet" href="<?php echo e(asset('themes/frontend')); ?>/css/slick-theme.css">
      
      
        <?php echo $__env->yieldContent('page_css'); ?>
   </head>


  

