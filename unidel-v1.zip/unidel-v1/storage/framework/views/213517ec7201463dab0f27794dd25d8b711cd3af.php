<?php $__env->startSection('page_title','Force | Personal - Force Motors'); ?>
<?php $__env->startSection('page_css'); ?>
	<link href="<?php echo e(asset('themes/frontend')); ?>/css/style-other-demo.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('themes/frontend')); ?>/css/commercial-page.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('themes/frontend')); ?>/css/personal-page.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('themes/frontend')); ?>/css/agriculture-page.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="agri-banner-wrap personal-baner-wrap">
		<div class="product-caption-img">
			<img class="img-responsive sky-bg" src="<?php echo e(asset('themes/frontend')); ?>/images/personal/personal-front.jpg">
			<img class="img-responsive product-img personal-product" src="<?php echo e(asset('themes/frontend')); ?>/images/personal/car.png">
		</div>
		<ul>
			<li><a href="<?php echo e(url('/commercial_vehicle')); ?>">commercial</a></li>
			<li><a href="<?php echo e(url('/agricultural_vehicle')); ?>">agriculture</a></li>
			<li><a href="<?php echo e(url('/personal_vehicle')); ?>" class="active">Personal</a></li>
		</ul>
		<h1>vehicles</h1>

	</section>
	<section class="product-section">
		<div class="container">
			<h1> Adventure</h1>
		</div>
	</section>

	<section class="product-row">
		<div class="container">
			<div class="row">
				<!-- Product 1st-->
				<div class="col-md-3 col-sm-3 col-xs-12 white-patch">
					<div id="personal-product" class="carousel slide product-bg" data-ride="carousel">
						<!-- Indicators -->
						<ol class="carousel-indicators product-indicator">
							<li data-target="#personal-product" data-slide-to="0" class="active"></li>
							<li data-target="#personal-product" data-slide-to="1"></li>
						</ol>
						<!-- Wrapper for slides -->
						<div class="carousel-inner text-center">
							<div class="item active">
								<a href="#">
									<img src="<?php echo e(asset('themes/frontend')); ?>/images/personal/Gurkha_xpedition.png" class="img-responsive" alt="personal product img">
									<div class="commercial-txt">
										<h3>gurkha xpedition</h3>
										<p>4 Cylinder, Common Rail</p>
									</div>
								</a>
							</div>
							<div class="item">
								<a href="#">
									<img src="<?php echo e(asset('themes/frontend')); ?>/images/personal/Gurkha_xplorer.png">
									<div class="commercial-txt">
										<h3>Gurkha xplorer</h3>
										<p>4 Cylinder, Common Rail</p>
									</div>
								</a>
							</div>
						</div>
						<!-- Left & Right controls-->
						<a class="left carousel-control hidden" href="#personal-product" data-slide="prev">
							<span class="glyphicon glyphicon-chevron-left"></span>
							<span class="sr-only">Previous</span>
						</a>
						<a class="right carousel-control hidden" href="#personal-product" data-slide="next">
							<span class="glyphicon glyphicon-chevron-right"></span>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_script'); ?>
	<script type="text/javascript">
        $('#personal-product').carousel({interval:false}); /*  initialized the carousel but don't start it  */
        var myInterval=false;

        $('#personal-product .carousel-inner').mouseover(function() {
            var ctrl = $("#personal-product .carousel-control .glyphicon-chevron-right");
            var interval=400;

            myInterval1 = setInterval(function(){
                ctrl.trigger("click");
            },interval);
        });

        $('#personal-product .carousel-inner').mouseout(function(){
            clearInterval(myInterval1);
            myInterval1 = false;
        });

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>