<?php $__env->startSection('page_title','ISME | Home'); ?>
<?php $__env->startSection('page_css'); ?>
 <link href="<?php echo e(asset('themes/frontend')); ?>/css/modal-video.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="banner-section">
  <div id="myCarousel" class="carousel slide " data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <span><a class="know-more-link" href="">Know More</a></span>
  </ol>


  <!-- Wrapper for slides -->
  <div class="carousel-inner">
     <div class="item active">
     <img class="hidden-xs" src="<?php echo e(asset('themes/frontend')); ?>/images/banner-2.png" alt="Banner">
      <img class="img-100 hidden-sm hidden-md hidden-lg" src="<?php echo e(asset('themes/frontend')); ?>/images/mobile-banner.png">
      <div class="carousel-caption">
        <h3>Learn to lead</h3>
        <div class="clearfix"></div>
         <p>From The Industry Experts</p>
        
         
      </div>
    </div>
    <div class="item">
      <img class="hidden-xs" src="<?php echo e(asset('themes/frontend')); ?>/images/banner-1.png" alt="Banner">
      <img class="img-100 hidden-sm hidden-md hidden-lg" src="<?php echo e(asset('themes/frontend')); ?>/images/mobile-banner-2.png">
       <div class="carousel-caption">
        <h3>Learn to master</h3>
        <div class="clearfix"></div>
        <p>At The Technically Advanced Centre Of Education</p>
           </div>
    </div>

    <div class="item">
     <img class="hidden-xs" src="<?php echo e(asset('themes/frontend')); ?>/images/banner-3.png" alt="Banner">
      <img class="img-100 hidden-sm hidden-md hidden-lg" src="<?php echo e(asset('themes/frontend')); ?>/images/mobile-banner-3.png">
      <div class="carousel-caption">
        <h3>Learn to Progress</h3>
        <div class="clearfix"></div>
         <p>At The Innovative Hub of Mumbai</p>
         
      </div>
    </div>

   
  </div>

  <!-- Left and right controls -->
  <!-- <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a> -->
</div>
 <!--  <div class="scroll-down">
    <div class="scroll-down-img">
      <img src="<?php echo e(asset('themes/frontend')); ?>/images/scroll-down.png" class="img-responsive center-block">
    </div>
  </div> -->
</section>


   <section class="our-mission-section">
    <!--  <div class="container">
       <h1 class="h1-1">Its our mission to make your </h1>
       <h1 class="h1-2">vision a reality</h1>
       <p>We aim to empower students with professional and work-integrated skills which will prepare them to be job ready or to create their own entrepreneurial ventures</p>
     </div> -->
     <div id="myCarousel-1" class="carousel slide carousel-fade" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel-1" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel-1" data-slide-to="1"></li>
   
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner ">
    <div class="item active">
      <h1 class="h1-1">It's our <span class="mission">mission</span> to make your </h1>
       <h1 class="h1-2">vision a reality</h1>
       <p>To empower and enrich your mind and skill set for the jobs of tomorrow but even more, for your entrepreneurial journey starting from today. </p>
    </div>

    <div class="item">
         <h1 class="h1-1">Its our mission to make your </h1>
       <h1 class="h1-2"><span class="vision">vision</span> a reality</h1>
       <p>To see you excel in every spectrum of life by simulating challenges of tomorrow starting from today.</p>
    </div>

  </div>

  <!-- Left and right controls -->
  <!-- <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a> -->
</div>
   </section>

   <section class="the-program-section">
     <div class="container">
       <h1><span class="title">Pro </span>  <span class="title-2">grams</span></h1>
       <div class="row">
         <div class="col-sm-4">
           <h2>Undergraduate Degree In Business <br> Management and Entrepreneurship
            <br>(BME)</h2>
           <p>Learn the groundwork</p>
           <a href="#">Know More</a>
         </div>
         <div class="col-sm-4">
            <h2>Post Graduate <br>Degree In <br>Management, Business <br>& Entrepreneurship (MBE)</h2>
            <p>Strengthen the skills</p> 
            <a href="#">Know More</a>
         </div>
         <div class="col-sm-4">
           <h2>Continuing <br>Education In The <br>Real World Scenario</h2>
            <p>Ace the market</p>
            <a href="#">Know More</a>
               
         </div>
       </div>
     </div>
   </section>
    <section class="section-video-slider">
    <div class="container-fluid text-center video-container">
    <div class="row">
      <div class="col-md-5 col-sm-5 col-xs-12 col-pad-vid">
         <iframe id="popup-youtube-player" src="https://www.youtube.com/embed/mh9H5Dqu4ao" frameborder="0" allowfullscreen="true" allowscriptaccess="always"></iframe>  
        
      </div>
      <div class="col-md-7 col-sm-7 col-xs-12 col-pad-vid">
        <div class="bxslider">
    <div class="img-wrapper">
       <div id="play-video-1">
       <img  class="video-thumbnail" src="<?php echo e(asset('themes/frontend')); ?>/images/vid-thumb-2.png">
       <div class="middle">
        <div class="text ">
          <img class="play" src="<?php echo e(asset('themes/frontend')); ?>/images/play.png">
          
        </div>

       </div>
       <div class="title-overlay ">Mr.Ronnie Screwvala <br> at ISME</div>
    </div>
      <div id="play-video-2">
      <img class="video-thumbnail" src="<?php echo e(asset('themes/frontend')); ?>/images/vid-thumb-4.png">
      <div class="middle">
        <div class="text ">
          <img class="play" src="<?php echo e(asset('themes/frontend')); ?>/images/play.png">
          
        </div>

       </div>
       <div class="title-overlay ">Mr. Piyush Goyal <br>at ISME</div>
    
    </div>
    </div>
    <div class="img-wrapper">
       <div id="play-video-3">
      <img   class="video-thumbnail" src="<?php echo e(asset('themes/frontend')); ?>/images/vid-thumb-3.png">
       <div class="middle">
        <div class="text ">
          <img class="play" src="<?php echo e(asset('themes/frontend')); ?>/images/play.png">
          
        </div>

       </div>
       <div class="title-overlay ">Hon'ble Chief Minister<br> of Maharashtra Shri <br>Devendra Fadnavis<br> inaugurating the ISME </div>
     
    </div>

       <div id="play-video-4">
      <img   class="video-thumbnail" src="<?php echo e(asset('themes/frontend')); ?>/images/vid-thumb-5.png">
         <div class="middle">
        <div class="text ">
          <img class="play" src="<?php echo e(asset('themes/frontend')); ?>/images/play.png">
          
        </div>

       </div>
       <div class="title-overlay ">Visit of Mr Geoffrey Garrett <br> Dean of Wharton School of the <br>University of Pennsylvania</div>
     
    </div>
    </div>
    <div class="img-wrapper">
     <div id="play-video-5">
      <img   class="video-thumbnail" src="<?php echo e(asset('themes/frontend')); ?>/images/vid-thumb-2.png">
         <div class="middle">
        <div class="text ">
          <img class="play" src="<?php echo e(asset('themes/frontend')); ?>/images/play.png">
          
        </div>

       </div>
       <div class="title-overlay ">Mr.Ronnie Screwvala <br> at ISME</div>
    </div>
     <div id="play-video-6">
      <img   class="video-thumbnail" src="<?php echo e(asset('themes/frontend')); ?>/images/vid-thumb-4.png">
         <div class="middle">
        <div class="text ">
          <img class="play" src="<?php echo e(asset('themes/frontend')); ?>/images/play.png">
          
        </div>

       </div>
       <div class="title-overlay ">Mr. Piyush Goyal <br>at ISME</div>
      
    </div>
    </div>
  </div>

      </div>
    </div>
     


    </div>
  </section>  
   <section class="buzz-section">
     <div class="container">
       <h1><span class="title">Join The </span>  <span class="title-2">Buzz</span></h1>
       <p>“It’s more than studying just textbooks when you get hands-on experience and continuous interaction with industry experts throughout the course at ISME.”</p>
       
     </div>
   </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_script'); ?>

<script type="text/javascript">
   jQuery(document).on('ready', function() {
    jQuery('#play-video-1').on('click', function() {
      jQuery("#popup-youtube-player")[0].src = "https://www.youtube.com/embed/qCI59OnxElw?autoplay=1&rel=0";
    });

    jQuery('#play-video-2').on('click', function() {
      jQuery("#popup-youtube-player")[0].src = "https://www.youtube.com/embed/tR0yp031TlA?autoplay=1&rel=0";
    });

    jQuery('#play-video-3').on('click', function() {
      jQuery("#popup-youtube-player")[0].src ="https://www.youtube.com/embed/nrEqDMH5Vr4?autoplay=1&rel=0";
    });

    jQuery('#play-video-4').on('click', function() {
      jQuery("#popup-youtube-player")[0].src ="https://www.youtube.com/embed/Mnt16p_P8Wc?autoplay=1&rel=0";
    });

    // jQuery('#play-video-5').on('click', function() {
    //   jQuery("#popup-youtube-player")[0].src ="https://www.youtube.com/embed/xAhOT5NeOEg?autoplay=1&rel=0";
    // });
    });
</script>
<script type="text/javascript">
   
 jQuery(document).on('ready', function() {

       $window = jQuery( window ).width();

      if($window<=767){
       jQuery('.bxslider').bxSlider({
        minSlides: 1,
        maxSlides: 1,
        slideWidth: 767,
        slideMargin: 0,
        auto: false,
      });
      }else if($window<=991){

        jQuery('.bxslider').bxSlider({
        minSlides: 2,
        maxSlides: 2,
        slideWidth: 991,
        slideMargin: 0,
        auto: false,
      });
      }else{

       jQuery('.bxslider').bxSlider({
        minSlides: 2,
        maxSlides: 2,
        slideWidth: 420,
        slideMargin: 0,
        auto: false,
      });

      }

      

    });

</script>
  <script>
          $(function() {
  $(window).scroll(function() {
    var scroll = $(window).scrollTop();

    if (scroll >= 600) {
      $(".main-navigation").addClass("fixed-header");
    } else {
      $(".main-navigation").removeClass("fixed-header");
    }
  });
});

      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>