<?php $__env->startSection('page_title','Unidel | Home'); ?>
<?php $__env->startSection('page_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

 <section>
  <div class="banner-section">
  <img src="<?php echo e(asset('themes/frontend')); ?>/images/unidel-banner.jpg" class="img-responsive">
</div>
</section>
      <section class="navigation-section">
         <div class="container">
          <div class="row">
           <ul class="list-inline social-icon-row pull-right">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><div class="inner-addon right-addon">
          <i class="glyphicon glyphicon-search"></i>
          <input type="text" class="form-control" placeholder="Search " />
        </div></li>
            </ul>
          </div>
      <!-- Static navbar -->
      <nav class="navbar navbar-default">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">
              <img src="<?php echo e(asset('themes/frontend')); ?>/images/unidel-logo.png" class="img-responsive">
            </a>

          </div>
          <div id="navbar" class="navbar-collapse collapse">
            
            <ul class="nav navbar-nav navbar-right">
              <li class="active"><a href="./">About Us <span class="sr-only">(current)</span></a></li>
              <li><a href="../navbar-static-top/">Ventures </a></li>
              <li><a href="../navbar-fixed-top/">Team</a></li>
              <li><a href="../navbar-fixed-top/">Contact</a></li>
            </ul>
          </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
      </nav>
    </div> <!-- /container -->
       </section>


<section class="unidel-group-section">
  <div class="container-fluid">
    <div class="row">
       <div class="col-sm-5 col-sm-offset-1 col-xs-12">
         <div class="text-wrapper">
        <h3><span class="title-1">Unidel</span> Group</h3>
       
        <p>The UNIDEL Group traces its history to the early 1900s as Rasiklal Maneklal & Company, a leading stock broking and investments firm of its time.</p>
        <a href="#">Know More</a>
      </div>
       </div>
       <div class="col-sm-6 grp-img col-xs-12">
        <!-- <img src="images/unidel-grp-sm.jpg" class="img-responsive"> -->
       </div>
    </div>
    <div class="container">
    <div class="row compnies-row">
      <div class="col-sm-4">
        <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/company-logo-1.png" class="img-responsive">
        <p>Asset Vantage is a powerful technology platform built to automate global investment management. AV securely provides a complete view of a family's entire net worth.</p>
      </div>
      <div class="col-sm-4">
        <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/company-logo-2.png" class="img-responsive">
        <p>SoftDEL enables automation OEM's engineer smart, connected products which are the backbone of the Industrial Internet of Things.</p>
      </div>
      <div class="col-sm-4">
         <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/company-logo-3.png" class="img-responsive">
         <p>ProTeen's gamified web and mobile platform guides high school and college students through the maze of real world career options and helps them to achieve their future goals by making intelligent academic choices.</p>
      </div>
    </div>
  </div>
  </div>
</section>
<section class="stories-section">
  <div class="container-fluid fluid-container">
   
      <div class="col-sm-8 bg-black-count">
          <div class="row row-padding">
              <div class="col-sm-3 col-width col-width-margin">
                <h3>15</h3>
                <p>Year of <br> Experience</p>
              </div>
              <div class="col-sm-3 col-width">
                <h3>28</h3>
                <p>Current  <br>Investment</p>
              </div>
              <div class="col-sm-3 col-width">
                <h3>06</h3>
                <p>Specialist  <br>Industries</p>
              </div>
              <div class="col-sm-3 col-width">
                <h3>04</h3>
                <p>Experienced  <br>Partners</p>
              </div>
          </div>
      </div>
      <div class="col-sm-4 sucess-story-block">
        <h4>Sucess Stories</h4>
         <div class="stories-slider">
          <div>Asset Vantage is a powerful technology platform built to automate global investment management. AV securely provides a complete view of a familys entire net worth.</div>
          <div>Asset Vantage is a powerful technology platform built to automate global investment management. AV securely provides a complete view of a familys entire net worth.</div>
          <div>Asset Vantage is a powerful technology platform built to automate global investment management. AV securely provides a complete view of a familys entire net worth.</div>
         
           </div>
        </div>
             
  </div>
</section>
<section>
  <div class="container">
    <div class="row">
        <div class="logo-slider">
          <div>
             <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-s-1.jpg" class="img-responsive">
          </div>
          <div>
             <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-s-2.jpg" class="img-responsive">
          </div>
          <div>
             <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-s-3.jpg" class="img-responsive">
          </div>
          <div>
             <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-s-4.jpg" class="img-responsive">
          </div>
          <div>
             <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-s-1.jpg" class="img-responsive">
          </div>
          <div>
             <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-s-2.jpg" class="img-responsive">
          </div>
          <div>
             <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-s-3.jpg" class="img-responsive">
          </div>
          <div>
             <img src="<?php echo e(asset('themes/frontend')); ?>/images/logo-s-4.jpg" class="img-responsive">
          </div>
         
           </div>
      </div>
  </div>
</section>
<section class="team-section">
  <div class="container">
     <h3>Team</h3>
     <div>

  <!-- Nav tabs -->
  <ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Home</a></li>
    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Profile</a></li>
    <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Messages</a></li>
    <li role="presentation"><a href="#settings" aria-controls="settings" role="tab" data-toggle="tab">Settings</a></li>
  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="home">...</div>
    <div role="tabpanel" class="tab-pane" id="profile">...</div>
    <div role="tabpanel" class="tab-pane" id="messages">...</div>
    <div role="tabpanel" class="tab-pane" id="settings">...</div>
  </div>

</div>
  </div>
</section>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_script'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>