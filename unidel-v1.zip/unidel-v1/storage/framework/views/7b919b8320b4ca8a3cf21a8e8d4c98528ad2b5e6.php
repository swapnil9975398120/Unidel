<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('page_title'); ?></title>
    <link rel="shortcut icon" href="/favicon.ico">
      <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- FontAwesome CDN -->

    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="<?php echo e(asset('themes/frontend')); ?>/css/custom.css" rel="stylesheet">
    <link href="<?php echo e(asset('themes/frontend')); ?>/css/programs.css" rel="stylesheet">

     <link href="<?php echo e(asset('themes/frontend')); ?>/css/style.css" rel="stylesheet">

   <!--  <link href="<?php echo e(asset('themes/frontend')); ?>/css/style-nav.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('themes/frontend')); ?>/css/the-force.css"> -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700,700i,900" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700,700i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400i,700i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora" rel="stylesheet">
    <!-- slider css -->
    <link href="<?php echo e(asset('themes/frontend')); ?>/css/slick.css" rel="stylesheet">
    <link href="<?php echo e(asset('themes/frontend')); ?>/css/slick-theme.css" rel="stylesheet">
    <link href="<?php echo e(asset('themes/frontend')); ?>/css/hamburger.css" rel="stylesheet">
    


    <?php echo $__env->yieldContent('page_css'); ?>
</head>
<section class="main-navigation">
         <div class="container-fluid">
      <!-- Static navbar -->
      <nav class="navigation">
              <div class="col-sm-2">
            <a class="navbar-brand" href="#">
              <img src="<?php echo e(asset('themes/frontend')); ?>/images/isme-logo.png" class="img-responsive">
            </a>
          </div>
          <div id="" class="col-sm-9">
            
            <ul class="nav navbar-nav navbar-right ">
              <li class="active hidden-xs"><a href="#">Programes</a></li>
              <li class="hidden-xs"><a href="#">Entrepreneurship</a></li>
              <li class="hidden-xs"><a href="#">Life at ISME</a></li>
              <li class="hidden-xs"><a href="#">Faculty</a></li>
              <!-- <li class=""><a href="#"><i class="fa fa-phone phone-icon" aria-hidden="true"></i><span class="ph-num"></span></a></li> -->
              <li class="nav-icon">
               <!--  <nav class="fullscreen-nav">
                    <ul class="main-menu">
                        <div class="topo flexcenter">
                            <li class="active hidden-sm hidden-md hidden-lg"><a href="#">Programs</a></li>
                           <li class="hidden-sm hidden-md hidden-lg"><a href="#">Life at ISME</a></li>
                           <li class="hidden-sm hidden-md hidden-lg"><a href="#">Faculty</a></li>
                           <li class="hidden-sm hidden-md hidden-lg"><a href="#"><i class="fa fa-phone phone-icon" aria-hidden="true"></i><span class="ph-num">+91 8433910202 </span></a></li>

                            <li><a href="#" class="nav-link">About</a></li>
                            <li><a href="#" class="nav-link">What is Happening at ISME</a></li> 
                            <li><a href="#" class="nav-link">Innovation and Entrepreneurship</a></li> 
                             <li><a href="#" class="nav-link">Corporate Connect </a></li> 
                            <li><a href="#" class="nav-link">ISME Impact</a></li> 
                            <li><a href="#" class="nav-link">Contact</a></li> 
                        </div>
                    </ul>
                </nav> -->
                <nav class="navimavi">
                <ul class="navi-nav">
                  <li class="dropdown inner">
                    <li class="hidden-lg hidden-md hidden-sm"><a href="#">Programes</a></li>
              <li class="hidden-lg hidden-md hidden-sm"><a href="#">Entrepreneurship</a></li>
              <li class="hidden-lg hidden-md hidden-sm"><a href="#">Life at ISME</a></li>
              <li class="hidden-lg hidden-md hidden-sm"><a href="#">Faculty</a></li>
              <li class="dropdown inner">
                                        <a href="#" ><span class="title-active">About</span></a>
                                        <ul class="dropdown-menu inner-dropdown col-md-6">
                                            <li>
                                                <a href="#">At a Glance</a>
                                            </li>
                                            <li>
                                                <a href="#">Ethos & Philosophy</a>
                                            </li>
                                            <li>
                                                <a href="#">Senior Leadership</a>
                                            </li>
                                            <li>
                                                <a href="#">Global Connect</a>
                                            </li>
                                            <li>
                                                <a href="#">Location & Campus</a>
                                            </li>
                                            <li>
                                                <a href="#">Manufacturing Facilities</a>
                                            </li>
                                            <li>
                                                <a href="#">Global Presence</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="dropdown inner">
                                        <a href="#"><span class="title-active">Admission</span></a>
                                        <ul class="dropdown-menu inner-dropdown col-md-6">
                                            <li>
                                                <a href="#">How To Apply</a>
                                            </li>
                                            <li>
                                                <a href="#">Deadlines & Decision</a>
                                            </li>
                                            <li>
                                                <a href="#">Application Form</a>
                                            </li>
                                            <li>
                                                <a href="#">FAQ'S</a>
                                            </li>
                                           
                                        </ul>
                                    </li>
                                    <li class="dropdown inner">
                                        <a href="#"><span class="title-active">Corporate Connect</span></a>
                                        <ul class="dropdown-menu inner-dropdown col-md-6">
                                            <li>
                                                <a href="#">On Campus Mentorship</a>
                                            </li>
                                            <li>
                                                <a href="#">Immesion & Projects</a>
                                            </li>
                                            <li>
                                                <a href="#">Intership & Placements</a>
                                            </li>
                                            
                                           
                                        </ul>

                                    </li>
                                    <li class="outer"><a href=> <span class="title-active">Careers</span></a></li>
                                    <li class="outer"><a href=> <span class="title-active">Alumni</span></a></li>
                                    <li class="outer"><a href=> <span class="title-active">Contact</span></a></li>
                </ul>
              </nav>
                <div class="menu">
                    <div class="hamburger hamburger--collapse">
                    <span class="hamburger-box">
                      <span class="hamburger-inner"></span>
                    </span>
                  </div>
                </div>
           </li>
            </ul>
          </div><!--/.nav-collapse -->
   
      </nav>
    </div>
</section>

