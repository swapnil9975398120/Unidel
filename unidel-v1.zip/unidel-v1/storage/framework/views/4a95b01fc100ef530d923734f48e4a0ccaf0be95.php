<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('page_title'); ?></title>
    <link rel="shortcut icon" href="/favicon.ico">
      <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- FontAwesome CDN -->

    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="<?php echo e(asset('themes/frontend')); ?>/css/style.css" rel="stylesheet">

    <link href="<?php echo e(asset('themes/frontend')); ?>/css/style-nav.css" rel="stylesheet">

    <link href="<?php echo e(asset('themes/frontend')); ?>/css/homepage.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('themes/frontend')); ?>/css/the-force.css">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('themes/frontend')); ?>/css/product-inner.css">

    <link href="<?php echo e(asset('themes/frontend')); ?>/css/style-other-demo.css" rel="stylesheet">
    <!-- slider css -->
    <link href="<?php echo e(asset('themes/frontend')); ?>/css/slick.css" rel="stylesheet">
    <link href="<?php echo e(asset('themes/frontend')); ?>/css/slick-theme.css" rel="stylesheet">

    <?php echo $__env->yieldContent('page_css'); ?>
</head>

<section class="navbar-sec hidden-xs">
    <div class="container">
        <nav class="navbar navbar-default force-navbar">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/Force_logo.jpg">
                    </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav"></ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li class="border-hover"><a href="#" >Center of Excellence</a></li>
                        <li class="border-hover"><a href="#">People</a></li>
                        <!-- <li><a href="#">Vehicle</a></li> -->
                        <li class="dropdown vehicle-dropdown <?php  $current_method = get_current_method()  ?> <?php if($current_method == 'commercial_vehicle' || $current_method == 'agricultural_vehicle' ||$current_method == 'personal_vehicle' ): ?> border-active <?php else: ?> border-hover <?php endif; ?>">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Vehicle</a>
                            <ul class="dropdown-menu <?php if($current_method == 'commercial_vehicle' || $current_method == 'agricultural_vehicle' ||$current_method == 'personal_vehicle' ): ?> hide <?php endif; ?>">
                                <li>
                                    <a href="<?php echo e(url('/commercial_vehicle')); ?>">
                                    <!-- <img src="<?php echo e(asset('themes/frontend')); ?>/images/Commercial_N_hover.png" onmouseover="this.src='<?php echo e(asset('themes/frontend')); ?>/images/Commercial_hover.png'"
                           onmouseout="this.src='<?php echo e(asset('themes/frontend')); ?>/images/Commercial_N_hover.png'" border="0" alt=""/> -->
                                        <h1>COMMERCIAL</h1>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/agricultural_vehicle')); ?>">
                                    <!-- <img src="<?php echo e(asset('themes/frontend')); ?>/images/Agricultural_N_hover.png" onmouseover="this.src='<?php echo e(asset('themes/frontend')); ?>/images/Agricultural_hover.png'"
                           onmouseout="this.src='<?php echo e(asset('themes/frontend')); ?>/images/Agricultural_N_hover.png'" border="0" alt=""/>
                            -->
                                        <h1>Agricultural</h1>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/personal_vehicle')); ?>">
                                    <!--<img src="<?php echo e(asset('themes/frontend')); ?>/images/Personal_N_hover.png" onmouseover="this.src='<?php echo e(asset('themes/frontend')); ?>/images/Personal_hover.png'"
                           onmouseout="this.src='<?php echo e(asset('themes/frontend')); ?>/images/Personal_N_hover.png'" border="0" alt=""/>
                            -->
                                        <h1>personal</h1>

                                    </a>
                                </li>
                            </ul>
                        </li>

                        <div id="myNav" class="overlay">
                            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                            <div class="overlay-content">
                                <ul class="outer-dropdown">
                                    <li class="dropdown inner strikeout-custom">
                                        <a href="#" class="dropdown-toggle"  role="button" aria-haspopup="true" aria-expanded="false">THE FORCE</a>
                                        <ul class="dropdown-menu inner-dropdown col-md-6">
                                            <li>
                                                <a href="#">European Association</a>
                                            </li>
                                            <li>
                                                <a href="#">Fully Vertically Integrated</a>
                                            </li>
                                            <li>
                                                <a href="#">Company Profile</a>
                                            </li>
                                            <li>
                                                <a href="#">Dr. Abhay Firodia Group</a>
                                            </li>
                                            <li>
                                                <a href="#">Our Founder</a>
                                            </li>
                                            <li>
                                                <a href="#">Manufacturing Facilities</a>
                                            </li>
                                            <li>
                                                <a href="#">Global Presence</a>
                                            </li>
                                        </ul>
                                    </li>

                                    <li><a href="#" class="strikeout-custom">HISTORY</a></li>
                                    <li class="dropdown inner strikeout-custom">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">INVESTORS</a>
                                        <ul class="dropdown-menu inner-dropdown col-md-6">
                                            <li>
                                                <a href="#">Board Of Directors</a>
                                            </li>
                                            <li>
                                                <a href="#">Financial Results</a>
                                            </li>
                                            <li>
                                                <a href="#">Shareholder's Information</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="dropdown inner strikeout-custom">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">MEDIA</a>
                                        <!-- <ul class="dropdown-menu inner-dropdown col-md-6">
                                           <li>
                                              <a href="#">Awards & Recognitions</a>
                                           </li>
                                           <li>
                                             <a href="#">FML in News</a>
                                           </li>

                                        </ul> -->
                                    </li>

                                    <li class="dropdown inner strikeout-custom">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">DEALERS</a>
                                        <ul class="dropdown-menu inner-dropdown col-md-6">
                                            <li>
                                                <a href="#">Dealer Locator</a>
                                            </li>
                                            <li>
                                                <a href="#">Be a Dealer</a>
                                            </li>

                                        </ul>
                                    </li>
                                    <li><a href="#" class="strikeout-custom">CSR</a></li>
                                    <li><a href="#" class="strikeout-custom">BSE / NSE</a></li>
                                    <!-- <li><a href="#" class="strikeout-custom">NSE</a></li> -->
                                    <li><a href="#" class="strikeout-custom">CONTACT US</a></li>
                                </ul>

                            </div>
                        </div>


                        <span style="font-size:30px;margin-left: 20px; cursor:pointer;color:#fff;" onclick="openNav()"><img src="<?php echo e(asset('themes/frontend')); ?>/images/Hamburger_menu.png"></span>
                    </ul>

                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
    </div>
</section>

<section class="visible-xs mobile-mode-nav">
    <nav class="navbar navbar-default ">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/Force_logo.jpg"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
                <ul class="nav navbar-nav">

                    <li><a href="#">Center of Excellence</a></li>
                    <li><a href="#">People</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Vehicle <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Commercial</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="#">Agricultural</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="#">Personal</a></li>
                            <li role="separator" class="divider"></li>
                        </ul>
                    </li>
                    <li><a href="#">The Force</a></li>
                    <li><a href="#">History</a></li>
                    <li><a href="#">Investor</a></li>
                    <li><a href="#">Media</a></li>
                    <li><a href="#">Dealer</a></li>
                    <li><a href="#">CSR</a></li>
                    <li><a href="#">BSE / NSE</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
</section>


