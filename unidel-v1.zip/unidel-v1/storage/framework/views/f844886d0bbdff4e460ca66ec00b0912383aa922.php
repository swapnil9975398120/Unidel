<section class="footer-section">
   <div class="container">
      <div class="footer-navigation text-center">
         <ul class="list-inline">

            <li><a href="#">Programmes</a></li>
            <li><a href="#">Entrepreneurship</a> </li>
            <li><a href="#">Life At ISME</a></li>
            <li><a href="#">Faculty </a></li>
            <!-- <li><a href="#">What is Happening at ISME</a> </li> -->
         </ul>
         <!-- <ul class="list-inline list-2">
            <li><a href="#">Innovation and Entrepreneurship</a></li>
            <li><a href="#">Corporate Connect</a></li>
            <li><a href="#">ISME Impact</a></li>
            <li><a href="#">Contact</a></li>
         </ul> -->
         <ul class="list-inline list-3">
            <li><a><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/talk-of-d-town.png"></a></li>
            <li><a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/econimics.png"></a></li>
            <li><a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/mumbai-mirror.png"></a></li>            <li><a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/business-world.png"></a></li>
         </ul>
      </div>
      <div class="row footer-address-section">
         <div class="col-sm-4">
            <h2><a href="tel:+91-8433910202">+91-8433910202</a></h2>
       
            <h5>ISME TOWER</h5>
            <p>One Indiabulls Centre, <br>
               Tower 2A, 6th Floor, <br>
               Lower Parel, Mumbai, <br>
               Maharashtra - 400013
            </p>
            <span><a class="mail-id" href="mailto:info@isme.co.in">info@isme.co.in</a></span>
            <ul class="list-inline social-icon">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-tumblr"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            </ul>
         </div>
         <div class="col-sm-4">
            <h2>Hear Us</h2>
            <p>"Digital Educators Symposium in association with @AdobeIndia  which was attended by leading Principal's & Academic Le… <a href="https://t.co/ra5Se4977R">https://t.co/ra5Se4977R...</a><br>
               
            </p>
            <p>
                Thank you @Inc42  for the feature <a href="https://t.co/UkoPQ1kMyp">https://t.co/UkoPQ1kMyp</a> <br>
               - RT @raakhektandon
            </p>
            <p>
                Great to welcome staff & students from @ismemumbai  recently to learn more about #entrepreneurship in #dubai <a href="https://t.co/LLHl…">https://t.co/LLHl…</a><br>
               - RT @ritdubai
            </p>
         </div>
         <div class="col-sm-4 form-section">
            <h2>We Want To Hear You</h2>
            <form>
               <div class="form-row">
                  <div class="form-group col-md-12">
                     <input type="text" class="form-control" id="inputName" placeholder="Name">
                  </div>
                  <div class="form-group col-md-6">
                     <input type="email" class="form-control" id="inputEmail4" placeholder="Email">
                  </div>
                  <div class="form-group col-md-6">
                     <input type="text" class="form-control" id="inputPassword4" placeholder="Mobile">
                  </div>
               </div>
               <div class="form-group col-sm-12">
                  <select class="form-control" id="exampleFormControlSelect1">
                     <option>City</option>
                     <option>Pune</option>
                     <option>Mumbai</option>
                  </select>
               </div>
               <div class="form-group col-sm-12">
                  <select class="form-control" id="exampleFormControlSelect1">
                     <option>Courses</option>
                     <option>Undergraduate Program</option>
                     <option>Post-Graduate Program</option>
                  </select>
               </div>
               <div class="col-sm-12">
                  <button type="submit " class="btn pull-right btn-submit">Send</button>
               </div>
            </form>
         </div>
      </div>
   </div>
</section>

<script src="<?php echo e(asset('themes/frontend')); ?>/js/jquery.min.js"></script>
 <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery.touchswipe/1.6.4/jquery.touchSwipe.min.js"></script>
<script type="text/javascript">
      $(".carousel").swipe({

  swipe: function(event, direction, distance, duration, fingerCount, fingerData) {

    if (direction == 'left') $(this).carousel('next');
    if (direction == 'right') $(this).carousel('prev');

  },
  allowPageScroll:"vertical"

});
 </script>
 
 <script src='http://cdnjs.cloudflare.com/ajax/libs/bxslider/4.2.5/jquery.bxslider.min.js'></script>
<script type="text/javascript" src="http://codegena.com/assets/js/youtube-embed.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
   // (function() {
   // $(".menu").on("click", function() {
   // $(this).toggleClass('open');
   // $('.fullscreen-nav').toggleClass('open');
   
   // return $(this).toggleClass('active');
   // });
   // }).call(this);
   
</script>
 
<script type="text/javascript">
   jQuery(function(){
  jQuery('.hamburger').on('click', function(){
    jQuery(this).toggleClass('is-active');
    jQuery('.navimavi').toggleClass('active');
  });
});
   
 </script>
<?php echo $__env->yieldContent('page_script'); ?>
</body>
</html>