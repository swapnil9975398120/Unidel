<?php $__env->startSection('page_title','Force | Commercial - Force Motors'); ?>
<?php $__env->startSection('page_css'); ?>
	<link href="<?php echo e(asset('themes/frontend')); ?>/css/style-other-demo.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('themes/frontend')); ?>/css/commercial-page.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('themes/frontend')); ?>/css/personal-page.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('themes/frontend')); ?>/css/agriculture-page.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="agri-banner-wrap commercial-banner-wrap">
	<div class="product-caption-img">
		<img class="img-responsive sky-bg" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/commercial-front.jpg">
		<img class="img-responsive product-img" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/school-van.png">
	</div>
	<ul>
		<li><a href="<?php echo e(url('/commercial_vehicle')); ?>" class="active">commercial</a></li>
		<li><a href="<?php echo e(url('/agricultural_vehicle')); ?>">agriculture</a></li>
		<li><a href="<?php echo e(url('/personal_vehicle')); ?>">Personal</a></li>
	</ul>
	<h1>vehicles</h1>

</section>

<section class="product-section commercial-section">
	<div class="container">
		<h1>light commercial</h1>
		<h2>vehicles - <span>passenger carrier</span></h2>
	</div>
</section>

<section class="product-row commercial-row">
	<div class="container">
		<div class="row">
		<!--product 1st  -->
			<!-- <div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg-unhoverd ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-3050.png" alt="balwan product img">
			    	<div class="commercial-txt">	
			    		<h3>Traveller 3050</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>	
			    	</a>
			    </div>	
			</div> -->
			<div class="col-md-3 col-sm-3 col-xs-12 white-patch">
                <div id="commercial-product-1" class="carousel slide product-bg" data-ride="carousel">
            
                    <ol class="carousel-indicators product-indicator">
                     <li data-target="#commercial-product-1" data-slide-to="0" class="active"></li> 
                      <li data-target="#commercial-product-1" data-slide-to="1"></li>
                      <li data-target="#commercial-product-1" data-slide-to="2"></li>
                      <li data-target="#commercial-product-1" data-slide-to="3"></li>
                    </ol>
            
                    <div class="carousel-inner">
                        <div class="item active">
                            <a href="#">
                                <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-3050.png" alt="balwan product img">
                                <div class="commercial-txt">	
                                	<h3>Traveller 3050</h3>
			    					<p>4 Cylinder, Common Rail</p>
			    				</div>	
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-3050.png" alt="balwan product img">
                                <div class="commercial-txt">	
                                	<h3>Traveller 3050</h3>
			    					<p>4 Cylinder, Common Rail</p>
			    				</div>	
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-3050.png" alt="balwan product img">
                                <div class="commercial-txt">	
                                	<h3>Traveller 3050</h3>
			    					<p>4 Cylinder, Common Rail</p>
			    				</div>	
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-3050.png" alt="balwan product img">
                                <div class="commercial-txt">	
                                	<h3>Traveller 3050</h3>
			    					<p>4 Cylinder, Common Rail</p>
			    				</div>	
                            </a>
                        </div>
                    </div>
            
                    <a class="left carousel-control hidden" href="#commercial-product-1" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control hidden" href="#commercial-product-1" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
		<!--product 2nd  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-3350.png" alt="balwan product img">
			    	<div class="commercial-txt">	
			    		<h3>Traveller 3350</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>	
			    	</a>
			    </div>	
			</div>
		<!--product 3rd  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-3700-super.png" alt="balwan product img">
				    <div class="commercial-txt">	
				    	<h3>Traveller 3700 super</h3>
				    	<p>4 Cylinder, Common Rail</p>
				    </div>
			    	</a>
			    </div>	
			</div>
		<!--product 4th  -->
			<!-- <div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg-unhoverd ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-School-Bus-3700.png" alt="balwan product img">
			    	<div class="commercial-txt">
				    	<h3>Traveller school bus 3700</h3>
				    	<p>4 Cylinder, Common Rail</p>
				    </div>
				    </a>
			    </div>	
			</div> -->

			<!-- Product 4th-->
            <div class="col-md-3 col-sm-3 col-xs-12 white-patch">
                <div id="commercial-product" class="carousel slide product-bg" data-ride="carousel">
            
                    <ol class="carousel-indicators product-indicator">
                     <li data-target="#commercial-product" data-slide-to="0" class="active"></li> 
                      <li data-target="#commercial-product" data-slide-to="1"></li>
                      <li data-target="#commercial-product" data-slide-to="2"></li>
                    </ol>
            
                    <div class="carousel-inner">
                        <div class="item active">
                            <a href="#">
                                <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-School-Bus-3700.png" alt="balwan product img">
                                <div class="commercial-txt">	
                                	<h3>Traveller school bus 3700</h3>
			    					<p>4 Cylinder, Common Rail</p>
			    				</div>	
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-School-Bus-3700.png" alt="balwan product img">
                                <div class="commercial-txt">	
                                	<h3>Traveller school bus 3700</h3>
			    					<p>4 Cylinder, Common Rail</p>
			    				</div>	
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-School-Bus-3700.png" alt="balwan product img">
                                <div class="commercial-txt">	
                                	<h3>Traveller school bus 3700</h3>
			    					<p>4 Cylinder, Common Rail</p>
			    				</div>	
                            </a>
                        </div>
                    </div>
            
                    <a class="left carousel-control hidden" href="#commercial-product" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control hidden" href="#commercial-product" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>

		<!--product 5th  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-cng.png" alt="balwan product img">
			    	<div class="commercial-txt">
				    	<h3>Traveller cng</h3>
				    	<p>4 Cylinder, Common Rail</p>
				    </div>		
			    	</a>
			    </div>	
			</div>
		<!--product 6th  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-4020-super.png" alt="balwan product img">
			    	<div class="commercial-txt">	
			    		<h3>Traveller 4020 super</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>	
			    	</a>
			    </div>	
			</div>
		<!--product 7th  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-ambulance.png" alt="balwan product img">
			    	<div class="commercial-txt">	
			    		<h3>Traveller ambulance</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>	
			    	</a>
			    </div>	
			</div>
		<!--product 8th  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-trauma-ambulance.png" alt="balwan product img">
			    	<div class="commercial-txt">
			    		<h3>Traveller trauma ambulance</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>	
			    	</a>	
			    </div>	
			</div>
		<!--product 9th  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-26.png" alt="balwan product img">
			    	<div class="commercial-txt">
			    		<h3>Traveller 26</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>
			    	</a>		
			    </div>	
			</div>
		<!--product 10th-->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-royale.png" alt="balwan product img">
			    	<div class="commercial-txt">	
			    		<h3>Traveller royale</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>	
			    	</a>
			    </div>	
			</div>
		<!--product 11th  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-smart-citibus.png" alt="balwan product img">
			    	<div class="commercial-txt">	
			    		<h3>Traveller smart citibus</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>
			    	</a>	
			    </div>	
			</div>
		<!--product 12th  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial/traveller-26-school-bus.png" alt="balwan product img">
			    	<div class="commercial-txt">	
			    		<h3>Traveller 26 school bus</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>
			    	</a>
			    </div>	
			</div>
		</div>	
	</div>
</section>

<section class="product-section commercial-section">
	<div class="container">
		<div class="pull-right">
			<h1>Multi utility</h1>
			<h2>vehicles - <span>passenger carrier</span></h2>
		</div>	
	</div>
</section>

<section class="product-row commercial-row">
	<div class="container">
		<div class="row">
		<!--product 1st  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Multiutility-passenger-carrier/Trax_cruiser.png" alt="Trax product img">
			    	<div class="commercial-txt">
			    		<h3>Trax Cruiser</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>
			    	</a>
			    </div>
			</div>
		<!--product 2nd  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Multiutility-passenger-carrier/Trax_toofan.png" alt="trax toofan product img">
			    	<div class="commercial-txt">	
			    		<h3>Trax Toofan</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>
			    	</a>
				</div>
			</div>
		<!--product 3rd  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Multiutility-passenger-carrier/Trax_Ambulance.png" alt="Trax ambulance product img">
			    	<div class="commercial-txt">
			    		<h3>Trax ambulance</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>
			    	</a>
				</div>
			</div>
		<!--product 4th  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Multiutility-passenger-carrier/Trax_cruiser_deluxe.png" alt="Trax cruiser deluxe product img">
			    	<div class="commercial-txt">
			    		<h3>Trax cruiser delux</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>
			    	</a>
				</div>
			</div>
		<!--product 5th  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Multiutility-passenger-carrier/Trax_cruiser_deluxe_.png" alt="Trax cruiser product img">
			    	<div class="commercial-txt">
			    		<h3>Trax cruiser delux</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>	
			    	</a>
				</div>
			</div>
		<!--product 6th  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Multiutility-passenger-carrier/Trax_School_van.png" alt="Trax school van product img">
			    	<div class="commercial-txt">
			    		<h3>Trax cruiser school van</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>
			    	</a>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="product-section commercial-section">
	<div class="container">
		<h1>small commercial</h1>
		<h2>vehicles - <span>goods carrier</span></h2>
	</div>
</section>

<section class="product-row commercial-row">
	<div class="container">
		<div class="row">
		<!--product 1st  -->
			<div class="col-md-3 col-sm-4 col-md-offset-3 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Small_Commercial/Trump_40.png" alt="Trump 40 product img">
			    	<div class="commercial-txt">
			    		<h3>Trum 40</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>	
			    	</a>
				</div>
			</div>
		<!--product 2nd  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Small_Commercial/Trump_40_hi_deck.png" alt="trump 40 hi-deck product img">
			    	<div class="commercial-txt">
			    		<h3>Trum 40 hi - deck</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>
			    	</a>
				</div>
			</div>
		<!--product 3rd  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Small_Commercial/Trump_40_CNG_hi_deck.png" alt="trump hi deck cng product img">
			    	<div class="commercial-txt">
			    		<h3>Trum 40 cng hi - deck</h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>	
			    	</a>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="product-section commercial-section">
	<div class="container">
		<div class="pull-right">
			<h1>Multi utility</h1>
			<h2>vehicles - <span>goods carrier</span></h2>
		</div>	
	</div>
</section>

<section class="product-row">
	<div class="container">
		<div class="row">
		<!--product 1st  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg bottom-zero">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Multiutility- goods-carrier/Trax_Kargo_King.png" alt="trax cargo king product img">
			    	<div class="commercial-txt">
			    		<h3>Trax cargo - king </h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>
			    	</a>
				</div>
			</div>
		<!--product 2nd  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg bottom-zero">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Multiutility- goods-carrier/Trax_Delivery_van.png" alt="trax delivery van product img">
			    	<div class="commercial-txt">
			    		<h3>Trax delivery van </h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>	
				</div>
			</div>
		</div>
	</div>
</section>			

<section class="product-section commercial-section">
	<div class="container">
		<h1>light commercial</h1>
		<h2>vehicles - <span>goods carrier</span></h2>
	</div>
</section>

<section class="product-row commercial-row">
	<div class="container">
		<div class="row">
		<!--product 1st  -->
			<div class="col-md-3 col-sm-4 col-md-offset-3 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial-goods-carrier/Traveller_Delivery_Van.png" alt="trax delivery van product img">
			    	<div class="commercial-txt">	
			    		<h3>Trax delivery van </h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>
			    	</a>	
				</div>
			</div>
		<!--product 2nd  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial-goods-carrier/Traveller_Shaktiman.png" alt="traveller shaktiman product img">
			    	<div class="commercial-txt">
			    		<h3>Traveller shaktiman </h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>
			    	</a>	
				</div>
			</div>
		<!--product 3rd  -->
			<div class="col-md-3 col-sm-4 col-xs-12 white-patch">
				<div class="product-bg ">
					<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/commercial/Light_Commercial-goods-carrier/Traveller_Delivery_Van_Wider.png" alt="trax delivery van wider product img">
			    	<div class="commercial-txt">
			    		<h3>Traveller delivery van wider </h3>
			    		<p>4 Cylinder, Common Rail</p>
			    	</div>
			    	</a>
				</div>
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_script'); ?>
	<script type="text/javascript">
        $('#commercial-product').carousel({interval:false}); /*  initialized the carousel but don't start it  */
        var myInterval=false;

        $('#commercial-product .carousel-inner').mouseover(function() {
            var ctrl = $("#commercial-product .carousel-control .glyphicon-chevron-right");
            var interval=400;

            myInterval1 = setInterval(function(){
                ctrl.trigger("click");
            },interval);
        });

        $('#commercial-product .carousel-inner').mouseout(function(){
            clearInterval(myInterval1);
            myInterval1 = false;
        });

	</script>

	<script type="text/javascript">
        $('#commercial-product-1').carousel({interval:false}); /*  initialized the carousel but don't start it  */
        var myInterval=false;

        $('#commercial-product-1 .carousel-inner').mouseover(function() {
            var ctrl = $("#commercial-product-1 .carousel-control .glyphicon-chevron-right");
            var interval=400;

            myInterval1 = setInterval(function(){
                ctrl.trigger("click");
            },interval);
        });

        $('#commercial-product-1 .carousel-inner').mouseout(function(){
            clearInterval(myInterval1);
            myInterval1 = false;
        });

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>