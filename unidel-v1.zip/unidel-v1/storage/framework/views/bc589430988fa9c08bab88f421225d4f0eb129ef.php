<?php $__env->startSection('page_title','ISME | Faculty'); ?>
<?php $__env->startSection('page_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section class="faculty-banner-section">
    <div class="container">
        <h1>The Faculty</h1>
    </div>
      <!-- <img class="hidden-xs img-100 img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/faculty-banner.jpg" alt="Banner"> -->
  </section>
  <section class="browse-by-section">
      <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-3 col-xs-12">
                <h2><span class="browse-title">Browse</span>by</h2>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-9 col-xs-12">
                <ul class="list-inline">
                    <li>
                         <select class="form-control" id="exampleFormControlSelect1">
                             <option>All Departments</option>
                             <option>1</option>
                             <option>2</option>
                         </select>
                        <!-- <input type="text" name="" class="dept-drpdwn" placeholder="All Departments"> -->
                    </li>
                    <li>Visiting Faculty</li>
                    <li>Faculty</li>
                    <li><div class="inner-addon right-addon">
          <i class="glyphicon glyphicon-search"></i>
          <input type="text" class="form-control" placeholder="Search By Name" />
        </div></li>
                </ul>
            </div>
        </div>
          
      </div>
  </section>
<section class="faculty-filter-section">
  <div class="container">

    <ul class="nav nav-tabs" role="tablist">
      <li role="presentation" class="active"><a href="#f1" aria-controls="home" role="tab" data-toggle="tab">A-B-C</a></li>
      <li role="presentation"><a href="#f2" aria-controls="f2" role="tab" data-toggle="tab">D-E-F</a></li> 
      <li role="presentation"><a href="#f3" aria-controls="f3" role="tab" data-toggle="tab">G-H-I</a></li> 
      <li role="presentation"><a href="#f4" aria-controls="f4" role="tab" data-toggle="tab">J-K-L</a></li> 
       <li role="presentation"><a href="#f5" aria-controls="f5" role="tab" data-toggle="tab">M-N-O</a></li>
      <li role="presentation"><a href="#f6" aria-controls="f6" role="tab" data-toggle="tab">P-Q-R</a></li>
      <li role="presentation"><a href="#f7" aria-controls="f7" role="tab" data-toggle="tab">S-T-U</a></li> 
      <li role="presentation"><a href="#f8" aria-controls="f8" role="tab" data-toggle="tab">V-W-X</a></li> 
      <li role="presentation"><a href="#f9" aria-controls="f9" role="tab" data-toggle="tab">Y-Z</a></li> 
    </ul>






 <!-- <ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Home</a></li>
    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Profile</a></li>
    <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Messages</a></li>
    <li role="presentation"><a href="#settings" aria-controls="settings" role="tab" data-toggle="tab">Settings</a></li>
  </ul> -->

  <!-- Tab panes -->
  <div class="tab-content">
    <div role="tabpanel" class="tab-pane fade in active" id="f1">
        
        <div class="filter-content-area">
          <div class="faculty-img-wrapper">
        <img src="<?php echo e(asset('themes/frontend')); ?>/images/faculty-1.jpg" class="img-responsive">
        <p>Dr.Amarpreet Singh</p>
      </div>
      
        <!-- <h3 class="details-panel">Founding Dean ISME & Chairperson at ISDI, ISDI |WPP & ISME is the driving force behind the institutions energy & excellence....
          <div class="collapse" id="1">
                <div class="card card-block">
                  Founding Dean ISME & Chairperson at ISDI, ISDI |WPP & ISME is the driving force behind the institutions energy & excellence
                 </div>
                 </div>
          <a id="" class="swapArchived btn  btn-show-details showArchieved" data-toggle="collapse" href="#1" aria-expanded="false" aria-controls="1">
                      Show Details </a>
          </h3> -->
          <div class="main_ctnt">
         <!--  <h3 class="details-panel">Founding Dean ISME & Chairperson at ISDI, ISDI |WPP & ISME is the driving force behind the institutions energy & excellence....</h3> -->
          <h3 class="show">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec magna tellus, vulputate in feugiat vel, auctor at ipsum. Curabitur imperdiet orci eget congue malesuada. Vestibulum gravida mi sed facilisis elementum. Phasellus sed eros nulla. Proin porta aliquam tristique. Suspendisse tincidunt augue eget nulla luctus porta. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec magna tellus, vulputate in feugiat vel, auctor at ipsum. Curabitur imperdiet orci eget congue malesuada. Vestibulum gravida mi sed facilisis elementum. Phasellus sed eros nulla. Proin porta aliquam tristique. Suspendisse tincidunt augue eget nulla luctus porta.</h3>
        </div>
        <div class="program-desc-wrapper">
        <h2>Program</h2>
          <p class="program-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim  ea commodo consequatNeque. <!-- <a href=
          "#"><span class="read-more">Read More</span></a> -->
          </p>
          <a class="btn btn-default pull-right knw-more-faculty-btn">Know More</a>
        </div>
     
    </div>   
    <div class="filter-content-area">
  
        <div class="faculty-img-wrapper">
        <img src="<?php echo e(asset('themes/frontend')); ?>/images/faculty-2.jpg" class="img-responsive">
        <p>Anuja himatrai hinduja</p>
      </div>
      
        <h3>She is a Brand strategist with 12 years of hands on experience in the in Advertising & Brand Management and 18 years of teaching experience.....<!-- <a href=
          "#"><span class="read-more">Read More</span></a> --></h3>
        <h2>Program</h2>
          <p class="program-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim  ea commodo consequatNeque. <!-- <a href=
          "#"><span class="read-more">Read More</span></a> -->
          </p>
          <a class="btn btn-default pull-right knw-more-faculty-btn">Know More</a>
     
    </div> 

    <div class="filter-content-area">
  
        <div class="faculty-img-wrapper">
        <img src="<?php echo e(asset('themes/frontend')); ?>/images/faculty-3.jpg" class="img-responsive">
        <p>Andre MostertGhura</p>
      </div>
      
        <h3>A Professor of Innovation, Management & Entrepreneurship at the University of East London. At ISME he teaches Entrepreneurship while preparing...<!-- <a href=
          "#"><span class="read-more">Read More</span></a> --></h3>
        <h2>Program</h2>
          <p class="program-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim  ea commodo consequatNeque. <!-- <a href=
          "#"><span class="read-more">Read More</span></a> -->
          </p>
          <a class="btn btn-default pull-right knw-more-faculty-btn">Know More</a>
     
    </div>
    <div class="filter-content-area">
  
        <div class="faculty-img-wrapper">
        <img src="<?php echo e(asset('themes/frontend')); ?>/images/faculty-4.jpg" class="img-responsive">
        <p>Bernard McSherry</p>
      </div>
      
        <h3>The Founding Dean at NJCU School of Business, New York. At ISME he teaches Behavioural Finance and Management Economics...<!-- a href=
          "#"><span class="read-more">Read More</span></a> --></h3>
        <h2>Program</h2>
          <p class="program-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim  ea commodo consequatNeque. <!-- <a href=
          "#"><span class="read-more">Read More</span></a> -->
          </p>
           <a class="btn btn-default pull-right knw-more-faculty-btn">Know More</a>

     
    </div>

    </div>
    <div role="tabpanel" class="tab-pane fade" id="f2">
      
         <div class="filter-content-area">
  
        <div class="faculty-img-wrapper">
        <img src="<?php echo e(asset('themes/frontend')); ?>/images/faculty-4.jpg" class="img-responsive">
        <p>Bernard McSherry</p>
      </div>
      
        <h3>The Founding Dean at NJCU School of Business, New York. At ISME he teaches Behavioural Finance and Management Economics...<a href=
          "#"><span class="read-more">Read More</span></a></h3>
        <h2>Program</h2>
          <p class="program-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim  ea commodo consequatNeque. <a href=
          "#"><span class="read-more">Read More</span></a>
          </p>
     
    </div>

    </div>
    <div role="tabpanel" class="tab-pane fade" id="f3">3</div>
    <div role="tabpanel" class="tab-pane fade" id="f4">4</div> 
    <div role="tabpanel" class="tab-pane fade" id="f5">5</div>
    <div role="tabpanel" class="tab-pane fade" id="f6">6</div>
    <div role="tabpanel" class="tab-pane fade" id="f7">7</div> 
    <div role="tabpanel" class="tab-pane fade" id="f8">8</div>
    <div role="tabpanel" class="tab-pane fade" id="f9">9</div>
  </div>
   

    

  </div>
</section>
<?php $__env->startSection('page_script'); ?>
  <script>
      // jQuery(function ($) {
      //     $('.swapArchived').on('click', function () {
      //         var $el = $(this),
      //             textNode = this.lastChild;
      //         $el.find('i').toggleClass('fa-plus fa-minus');
      //         textNode.nodeValue = '' + ($el.hasClass('showArchieved') ? 'Hide Details' : 'Show Details')
      //         $el.toggleClass('showArchieved');
      //     });
      // });

    </script>
    <script>
$(function() {
var showTotalChar = 200, showChar = "Show (+)", hideChar = "Hide (-)";
$('.show').each(function() {
var content = $(this).text();
if (content.length > showTotalChar) {
var con = content.substr(0, showTotalChar);
var hcon = content.substr(showTotalChar, content.length - showTotalChar);
var txt= con +  '<span class="dots">...</span><span class="morectnt"><span>' + hcon + '</span>&nbsp;&nbsp;<a href="" class="showmoretxt">' + showChar + '</a></span>';
$(this).html(txt);
}
});
$(".showmoretxt").click(function() {
if ($(this).hasClass("sample")) {
$(this).removeClass("sample");
$(this).text(showChar);
} else {
$(this).addClass("sample");
$(this).text(hideChar);
}
$(this).parent().prev().toggle();
$(this).prev().toggle();
return false;
});
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>