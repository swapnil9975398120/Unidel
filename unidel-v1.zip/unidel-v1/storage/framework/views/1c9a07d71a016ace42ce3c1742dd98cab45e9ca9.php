<section class="footer-section">
   <div class="container">
      <div class="footer-navigation text-center">
         <ul class="list-inline">
            <li><a href="#">Home</a></li>
            <li><a href="#">Programs</a></li>
            <li><a href="#">Life at ISME</a> </li>
            <li><a href="#">Faculty</a></li>
            <li><a href="#">About </a></li>
            <li><a href="#">What is Happening at ISME</a> </li>
         </ul>
         <ul class="list-inline list-2">
            <li><a href="#">Innovation and Entrepreneurship</a></li>
            <li><a href="#">Corporate Connect</a></li>
            <li><a href="#">ISME Impact</a></li>
            <li><a href="#">Contact</a></li>
         </ul>
         <ul class="list-inline list-3">
            <li><a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/featured.png"></a></li>
            <li><a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/econimics.png"></a></li>
            <li><a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/mumbai-mirror.png"></a></li>            <li><a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/business-world.png"></a></li>
         </ul>
      </div>
      <div class="row footer-address-section">
         <div class="col-sm-4">
            <h2><a href="tel:+91 8433910202">+91-8433910202</a></h2>
            <h5>ISME TOWER</h5>
            <p>One Indiabulls Centre, Tower 2A, <br>
               6th FloorLower Parel, Mumbai, <br>
               Maharashtra, 400013
            </p>
            <span><a href="mail-to:info@isme.co.in">info@isme.co.in</a></span>
            <ul class="list-inline social-icon">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-tumblr"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            </ul>
         </div>
         <div class="col-sm-4">
            <h2>Live Tweets</h2>
            <p>"Whether we're talking to a 19 year old or 
               a 30 year old, we're talking to someone 
               with an intent".<br>
               - Leroy Alvares #DigitallyYours 
            </p>
            <p>
               We're tracking as you're talking" <br>
               - Leroy Alvares #DigitallyYours 
            </p>
         </div>
         <div class="col-sm-4 form-section" id="getintouch">
            <h2>Get in touch</h2>
            <form>
               <div class="form-row">
                  <div class="form-group col-md-12">
                     <input type="text" class="form-control" id="inputName" placeholder="Name*">
                  </div>
                  <div class="form-group col-md-6">
                     <input type="email" class="form-control" id="inputEmail4" placeholder="Email*">
                  </div>
                  <div class="form-group col-md-6">
                     <input type="text" class="form-control" id="inputPassword4" placeholder="Mobile*">
                  </div>
               </div>
               <div class="form-group col-sm-12">
                 <!--  <input type="text" class="form-control" id="inputAddress" placeholder=" Date of Birth"> -->
                  <input class="form-control" id="datepicker" name="date" placeholder="Date of Birth*">
               </div>
               <div class="form-group col-sm-12">
                  <select class="form-control" id="exampleFormControlSelect1">
                     <option value="" disabled selected>Programs</option>
                     <option>Undergraduate Program</option>
                     <option>Post-Graduate Program</option>
                  </select>

               </div>
               <div class="col-sm-12">
                  <button type="submit " class="btn pull-right btn-submit">Send</button>
               </div>
            </form>
            </div>
      </div>
   </div>
</section>
<script src="<?php echo e(asset('themes/frontend')); ?>/js/jquery.min.js"></script>
<script src="<?php echo e(asset('themes/frontend')); ?>/js/slick.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <script src="<?php echo e(asset('themes/frontend')); ?>/js/jquery.malihu.PageScroll2id.js" type="text/javascript"></script>
 <script>
   (function ($) {
       $(window).load(function () {
   
           /* Page Scroll to id fn call */
           $("#page-scrl a,a[href='#top'],a[rel='m_PageScroll2id']").mPageScroll2id({
               highlightSelector: "#page-scrl a"
           });
           $("#page-scrl-xs li a,a[href='#top'],a[rel='m_PageScroll2id']").mPageScroll2id({
               highlightSelector: "#main-nav-xs a"
           });
   
           /* demo functions */
           $("a[rel='next']").click(function (e) {
               e.preventDefault();
               var to = $(this).parent().parent("section").next().attr("id");
               $.mPageScroll2id("scrollTo", to);
           });
   
       });
   })(jQuery);
</script>
<script type="text/javascript">
   (function() {
   $(".menu").on("click", function() {
   $(this).toggleClass('open');
   $('.fullscreen-nav').toggleClass('open');
   
   return $(this).toggleClass('active');
   });
   }).call(this);
   
</script>
<script type="text/javascript">
$('#mySelect').change(

function () {
    $('#mySelect').css("background", $("select option:selected").css("background-color"));
});   
</script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
      <script type="text/javascript">
      
         var dateToday = new Date();
      $('#datepicker').datepicker({                                     
    format: 'dd-mm-yyyy',
                    
                    endDate:'-18y',
                  
                    
      });
         
      </script>
<?php echo $__env->yieldContent('page_script'); ?>
</body>
</html>