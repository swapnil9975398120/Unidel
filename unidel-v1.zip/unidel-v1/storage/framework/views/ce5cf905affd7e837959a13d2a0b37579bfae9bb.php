<?php $__env->startSection('page_title','Force | About'); ?>
<?php $__env->startSection('page_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <!-- <section class="about-banner">
    <img class="img-responsive img-100 hide" src="<?php echo e(asset('themes/frontend')); ?>/images/about/about-banner-1.png">
        <div class="container">
            <div class="about-banner-text">
                <h1>The <br/>force</h1>
                
                    <p>Force Motors is a fully,<br/> vertically integrated <br/> automobile company,</p>
                    <p>with expertise in design, development and manufacture of the full spectrum of automotive components, aggregates and vehicles. Its range includes Small Commercial Vehicles, Multi-Utility Vehicles (MUV), Light Commercial Vehicles (LCV), Sports Utility Vehicles (SUV) and Agricultural Tractors. So no matter what the need be, Force has a solution to offer. Force provides appropriate solutions for transport - both goods as well as passenger - rugged, reliable and efficient transport solutions for every need - Rural or Urban, long distance or local, over good roads or bad tracks
                    </p>
            </div>
        </div>
</section> -->
<section class="about-banner">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4">
                <div class="about-banner-text">
                    <h1>The <br/>force</h1>
                </div>  
            </div>
            <div class="col-md-8 col-sm-12">
                <div class="about-parent">
                    <img class="img-responsive " src="<?php echo e(asset('themes/frontend')); ?>/images/about/about-caption.jpg">
                        <div class="about-banner-text">
                            <p>Force Motors is a fully,<br/> vertically integrated <br/> automobile company,</p>
                            <p>with expertise in design, development and manufacture of the full spectrum of automotive components, aggregates and vehicles. Its range includes Small Commercial Vehicles, Multi-Utility Vehicles (MUV), Light Commercial Vehicles (LCV), Sports Utility Vehicles (SUV) and Agricultural Tractors. So no matter what the need be, Force has a solution to offer. Force provides appropriate solutions for transport - both goods as well as passenger - rugged, reliable and efficient transport solutions for every need - Rural or Urban, long distance or local, over good roads or bad tracks
                            </p>
                        </div>
                </div>      
            </div>
        </div>
    </div>
</section>

<section class="vertically-integrated">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-4">
                <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/about/vertically-integrated.jpg">
            </div>
            <div class="col-md-6 col-sm-8">
                <h1>fully vertically <br/> integrated</h1>
                <p>A vertically integrated automotive Manufacturing Company with wide spheres of excellence.</p>
                <p>
                    Force Motors is a fully vertically integrated automobile company, with expertise in design, development and manufacture of the full spectrum of automotive components, aggregates and vehicles. Its range includes Traveller light commercial vehicles, Trax multi-utility and cross country vehicles, Trump small commercial vehicles, and the Balwan range of Agricultural Tractors.The company continues in the founder's vision of providing efficient,utilitarian vehicles that empower the individual entrepreneur to meet his and country's ever changing needs.
                </p>
            </div>
        </div>
    </div>
</section>

<section class="europian-association">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-4 pull-right">
                <img class="img-responsive img-100 hidden-xs" src="<?php echo e(asset('themes/frontend')); ?>/images/about/association.jpg">
                <img class="img-responsive img-100 visible-xs" src="<?php echo e(asset('themes/frontend')); ?>/images/about/EXP_Img.png">
            </div>

            <div class="col-md-6 col-sm-8 col-md-offset-1">
                <h1>europian association</h1>
                <p>Force Motors to produce and test the engines for all cars and SUVs to be made in India.</p>
                <p>A state of the art factory has been built to the exacting standards of BMW by Force Motors in Chennai close to the BMW car factory in 2015. This plant has a capacity to manufacture and test 20,000 engines per year. In 2016 a new state-of-the-art plant has been commissioned at Chakan near the Mercedes Benz car manufacturing facility that is dedicated solely to the production of engines and Axles for all Cars and SUVs made in India.  This facility has a capacity of manufacturing and testing 20,000 engines per annum. A compact yet extremely modern facility with a high degree of attention to detail assures the highest quality and precise control on process parameters.  These plants are completely air conditioned with high level of dust control to safeguard product quality. Where essential, most modern technology is employed for ensuring assembly and joinery processes with computer controlled precision equipment. The combination of the premium design of the engines, along with the best practices in assembly and testing processes, results in the production of outstanding engines and axles. Force Motors is the only such company in the world that produces and tests the engines for two leading European luxury car makers. Fully aware of the strength of Force Motors, in terms of engineering infrastructure and capabilities, Rolls Royce PS has entered in to joint venture with Force Motors to produce engines for multiple applications like rail and power generation including associated spare parts for Indian as well as global markets.
                </p>
            </div>
            
        </div>
    </div>  
</section>

<section class="overseas-presence">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-4">
                <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/about/overseas.jpg">
            </div>
            <div class="col-md-6 col-sm-8">
                <h1>overseas <br/> presence</h1>
                <p>Force Motors is a highly flexible, vertically integrated automotive company that can cater to all types of markets, including niche markets, by providing customized 'country specific' modifications.
                </p>
                <p>
                    Force Motors has a formidable product range in all segments, be it small commercial vehicles, light commercial vehicles, multi utility vehicles and agricultural vehicles.
                    Over the last five decades it has partnered with leading global automotive names like Daimler, ZF, Ricardo, Bosch and MAN. Through these associations it has developed necessary expertise in-house for design, development and manufacture of automobiles, sub-systems, components and aggregates.
                    The company exports its complete range of world class products to various countries in Middle East, Asia, Latin America and Africa.
                </p>
            </div>
        </div>
    </div>
</section>

<section class="manufacturing-facility">
    <div class="container">
        <h1>manufacturing facility</h1>
        <div class="row">
            <div class="col-md-4 col-sm-4">
                <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/about/facility-1.jpg" alt="facility image"/>
            </div>
            <div class="col-md-4 col-sm-4">
                <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/about/facility-2.jpg" alt="facility image"/>
            </div>
            <div class="col-md-4 col-sm-4">
                <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/about/facility-3.jpg" alt="facility image"/>
            </div>
        </div>
    </div>
</section>

<section class="firodia-group">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4 pull-right">
                <h1>dr. abhay</h1>
                <h1>firodia</h1>
                <h1>group</h1>
                <p class="firodia-para">The group companies provide end-to-end technologically advanced automotive solutions.</p>
                <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/history-border.png">
            </div>

            <div class="col-md-8 col-sm-8">
                <p>The group of companies led by Dr. Abhay Firodia isone of India’s pioneering industrial houses focusing exclusively in the automotive domain.</p>
                <p>
                    The group companies provide end-to-end technologically advanced automotive solutions, ranging from its core competence of manufacturing light transport vehicles to engines and axles for leading international OEMs to producing a large variety of critical aluminum parts (both high pressure die casting and gravity die casting) for almost all leading automotive players in the country and globally. 
                </p>
                <ul>
                    <li>
                    <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/about/Force_Hover.png">
                    </li>
                    <li>
                        <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/about/Jayahind_Hover.png">
                    </li>
                    <li>
                        <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/about/JayahindMontupet_Hover.png">
                    </li>
                    <li>
                        <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/about/Rivulus_Hover.png">
                    </li>
                    <li>
                        <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/about/Pinnacle_Hover.png">
                    </li>                   
                    <li>
                        <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/about/ShriFirodiaTrust_Hover.png">
                    </li>
                </ul>
            </div>
            

        </div>
    </div>
</section>

<section class="founder-sec">
    <div class="white-bg"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-5 col-sm-5">
                    <h1>Our</h1>
                    <h1>Founder</h1>
                    <h2>n.k firodia</h2>
                    <p class="founder-txt">Our founder, Shri Navalmal Kundanmal Firodia -</p>
                    <p>Freedom Fighter and dedicated Gandhian, participated in the Freedom struggle, joining the Non-cooperation Movement in 1932 and the Quit India Movement in 1942. His vision of an independent and industrially strong nation inspired his many achievements. He pioneered the automotive industry in India, first founding Jaya Hind Industries Pvt. Ltd. in 1947.</p>
                    <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/history-border.png">
                </div>
                <div class="col-md-6 col-md-offset-1 col-sm-6">
                    <img class="img-responsive firodia-img"  src="<?php echo e(asset('themes/frontend')); ?>/images/about/founder.jpg">
                </div>
            </div>
    </div>
</section>

<!-- <section>
    <img src="<?php echo e(asset('themes/frontend')); ?>/images/about/founder-bg-1.jpg" class="img-responsive img-100">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="cust-txt">
                    <h1>Our</h1>
                    <h1>Founder</h1>
                </div>
            </div>  
        </div>  
    </div>  
</section> -->

<section class="company-profile">
    <div class="container">
        <div class="row">
        <div class="col-md-4 col-sm-4 pull-right">
                <h1>company</h1>
                <h1>profile</h1>
                <p class="founder-txt firodia-para">327th amongst India'a Fortune 500 Companies.</p>
                <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/history-border.png">
            </div>

            <div class="col-md-8 col-sm-8">
                <p class="founder-txt">
                    Force Motors Limited is the flagship company of the Dr. Abhay Firodia Group. The company, a pioneer of the LCV Industry has given India iconic brands like the Tempo, Matador, Minidor and Traveller.
                </p>

                <p>
                    Over the last five decades it has partnered with leading global automotive names like Daimler, ZF, Bosch and MAN and through these associations developed comprehensive expertise in-house for design, development and production of the entire range of automobiles. 
                    In 2016, Force Motors has been ranked 327th amongst India’s Fortune 500 Companies. This rank is an upward jump as the company was ranked 395thin the year 2015.
                    Force Motors has manufacturing facilities at Akurdi and Chakan (Maharashtra), Pithampur (Madhya Pradesh) and Chennai (Tamil Nadu) and employs over 8500 persons. 
                </p>
            </div>
            
        </div>
    </div>
</section>

<section class="brands-sec">
    <div class="container">
        <h1>our brands</h1>
        <div class="brands">
                  <div>
                     <div class="brand-wraper">
                        <h2>Traveller</h2>
                            <div class="overlay-div">
                                <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/about/traveller.jpg">
                            </div>
                        <p>
                            Originally designed and produced by Mercedes Benz AG, Germany as T1 Transporter, it is now manufactured in India as the "Traveller". This range of passenger and goods carriers is powered by the fuel efficient TD 2200 Common rail engine available in both BS III and IV versions. So whether it is for personal or business use, movement of men or material, the Traveller is an ideal choice. An iconic brand, the Traveller is one of the most popular inter and intra-city mobility vehicles in the country today. The recently launched variant in this range is called the Traveller 26.
                        </p>
                     </div>
                  </div>
                  <div>
                    <div class="brand-wraper">
                    <h2>trax</h2>
                        <div class="overlay-div">
                            <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/about/trax.jpg">
                        </div>
                        <p>
                            Trax is the first fully indigenous multi utility vehicle developed in the country. Over the past two decades it has established itself as the preferred people and goods carrier in rural India.
                            The Trax is a rugged, reliable; all-terrain vehicle powered by the legendary Mercedes- OM 616 derived diesel engine. Tough and stylish with durable steel pressed body primed with state-of-the-art CED process, the Trax has unmatched off-road applications for people and goods transport.
                        </p>
                    </div> 
                  </div>
                  <div>
                    <div class="brand-wraper"> 
                    <h2>gurkha</h2>
                        <div class="overlay-div">
                            <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/about/gurkha.jpg">
                        </div>
                        <p>
                            Styled on the lines of the legendary Mercedes G Wagen and powered by the Mercedes OM 616 derived turbocharged intercooled direct injection diesel engine developing 80hp and 340 Nm torque, Force Gurkha is the only extreme off-roader vehicle (E.O.V) which comes with differential locks on both front and rear axles, air intake snorkel, class leading ground clearance, a factory fitted hard top with air conditioning and five forward facing seats making it capable to take on any type of terrain in any season.
                        </p>
                    </div> 
                  </div>
                  <div>
                    <div class="brand-wraper">
                    <h2>balwan</h2>
                        <div class="overlay-div">
                           <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/about/balwan.jpg">
                        </div>
                        <p>
                            Force One is one of the finest sports utility vehicles made by an Indian OEM. The turbocharged Force One beats faster than any other SUV in its segment. Infused with a new 2.2 liter FMTECH Common Rail engine, its subdued growl is like a beast waiting to be unleashed. It is available in EX, SX and LX variants.
                            Technologically advanced, great road presence, excellent ride and handling, immense space creating comfort at a very competitive price are some of the features of the Force One.
                        </p>
                    </div> 
                  </div>
                  <div>
                    <div class="brand-wraper">
                    <h2>balwan</h2>
                        <div class="overlay-div">
                           <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/about/balwan.jpg">
                        </div>   
                        <p>
                            Force One is one of the finest sports utility vehicles made by an Indian OEM. The turbocharged Force One beats faster than any other SUV in its segment. Infused with a new 2.2 liter FMTECH Common Rail engine, its subdued growl is like a beast waiting to be unleashed. It is available in EX, SX and LX variants.
                            Technologically advanced, great road presence, excellent ride and handling, immense space creating comfort at a very competitive price are some of the features of the Force One.
                        </p>
                    </div> 
                  </div>


                  
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>