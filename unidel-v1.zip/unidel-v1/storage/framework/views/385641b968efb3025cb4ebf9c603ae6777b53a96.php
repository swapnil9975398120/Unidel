<?php $__env->startSection('page_title','ISME | Undergraduate'); ?>
<?php $__env->startSection('page_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section>
     
</section>
  <section>
      <div class="container">
          
      </div>
  </section>


  <section class="banner-section program-banner-section">
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
 
  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="<?php echo e(asset('themes/frontend')); ?>/images/under-graduate-banner.png" class="hidden-xs img-responsive">
      <img class="img-100 hidden-sm hidden-md hidden-lg mbl-banner" src="<?php echo e(asset('themes/frontend')); ?>/images/mobile-banner-program.png">
       <div class="carousel-caption">
        <h3>Business Management </h3>
        <h3>and Entrepreneurship<span class="bme">(BME)</span></h3>
        <div class="clearfix"></div>
         <p>Redefining Undergraduate Studies</p>
        <!--  <div class="clearfix"></div>
         <p> leaders</p> -->
      </div>
    </div>

</div>
</section>
<section class="welcome-section philosophy-section">
       <div class="container">

        <div class="row">
            <div class="col-lg-6 col-sm-7">
              <h2>BME Philosophy</h2>
              <div class="philosophy-text-wrapper">
                  <p>We aim to empower students with professional and work-integrated skills, which will prepare them to be job ready or create their own entrepreneurial ventures.</p>
                 <p>ISME's Business Management & Entrepreneurship (BME) course is a 3-year career oriented Program, designed to shape individuals into young business professionals. The program has been curated with support from business, industry, academic and real world practitioners and it provides students with experiential learning within a vast educational framework.</p>
                 <p>ISME and BME are not affiliated to the University of  Mumbai.</p>
               </div>
            </div>
            <div class="col-lg-6 col-sm-5">
                <div class="philosophy-bg-wrapper">
                    <p>"Our vision is to inspire and challenge future business minds by creating an environment conducive for innovation and learning."</p>
                </div>
               <!-- <img  src="<?php echo e(asset('themes/frontend')); ?>/images/quote.png" class="img-responsive mob-img-padding"> -->
            </div>
        </div>
       </div>
   </section>
 <section class="course-section">
 <div class="container">
        <h2>Proposed Course Curriculum - 1st Year</h2>
        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
          <div class="panel panel-default">
            <div class="panel-heading default-panel-clr" role="tab" id="headingOne">
              <h4 class="panel-title">
                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                  Management 101: Principles of Management
                   <i class="more-less fa fa-minus fa_custom fa-lg pull-right" title="Expand"></i>
                </a>

              </h4>
              
            </div>
            <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
              <div class="panel-body">
                 <p>
                  Management is an art and a science of assisting people in achieving their goals collaboratively. 
                    This course will enable students to understand the dynamic nature of management. 
                    It explains the importance of management and helps them understand the role of a manager. 
                    It introduces them to management processes and their basic functions of Planning, Organizing and Employee Motivation. It also acquaints the students with the classical and behavioural management perspectives, which explore the evolution of the discipline over a period of time. The course is ultimately aimed at equipping students with the skills and training for managing
                    organizational change and innovation in their future careers.
              </p>
              </div>
            </div>
          </div>
          <div class="panel panel-default">
            <div class="panel-heading panel-clr" role="tab" id="headingTwo">
              <h4 class="panel-title">
                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                 Finance 101: Introduction to Finance
                   <i class="more-less fa fa-plus fa_custom fa-lg pull-right" title="Expand"></i>
                </a>
              </h4>
            </div>
            <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
              <div class="panel-body">
            

              </div>
            </div>
          </div>

        </div>



         
     </div>
 </section>   

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_script'); ?>
<script>
    function toggleIcon(e) {
        $(e.target)
            .prev('.panel-heading')
            .find(".more-less")
            .toggleClass('fa-plus fa-minus')
            .attr('title', $(this).find(".more-less").hasClass('fa-plus') ? 'Expand':'Collapse');
    }
    $('.panel-group').on('hidden.bs.collapse', toggleIcon);
    $('.panel-group').on('shown.bs.collapse', toggleIcon);
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>