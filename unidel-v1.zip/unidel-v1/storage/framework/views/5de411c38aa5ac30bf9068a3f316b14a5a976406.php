<section class="footer-bg ">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-6 col-xs-12">
                <div class="number-wraper">
                    <div class="personal-wrap">
                        <a href="tel:18002333000">1800 2333 000</a>
                        <p>Personal Vehicles</p>
                    </div>
                    <div class="commercial-wrap">
                        <a href="tel:18002335000">1800 2335 000</a>
                        <p>commercial Vehicles</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6">
                <h1>Contact</h1>
            </div>
        </div>


        <div class="row">
            <div class="col-md-3 col-sm-3 col-xs-6">
                <h2>Center of Excellence</h2>
                <ul class="list-wrap">
                    <li><a href="#">Quality</a></li>
                    <li><a href="#">High Technology Aggregates</a></li>
                    <li><a href="#">Engineering</a></li>
                    <li><a href="#">R&D</a></li>
                    <li><a href="#">Manufacturing</a></li>
                </ul>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-6">
                <h2>Vehicle</h2>
                <ul class="list-wrap">
                    <li><a href="#">Commercial</a></li>
                    <li><a href="#">Agricultural</a></li>
                    <li><a href="#">Personal</a></li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12">
                <h2>People</h2>
                <ul class="list-wrap">
                    <li><a href="#">Working @ FML</a></li>
                    <li><a href="#">Learning & Development</a></li>
                    <li><a href="#">Employee Benefits</a></li>
                    <li><a href="#">Current Job Openings/ Careers</a></li>
                </ul>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <!-- <h2>Contact Form</h2> -->
                <form class="footer-form">
                    <div class="form-group">
                        <div class="">
                            <input type="text" class="form-control transparent-bg" name="your-name" placeholder="Name">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <input type="email" class="form-control transparent-bg" name="your-email" placeholder="email">
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <input type="number" class="form-control transparent-bg" name="your-phone" placeholder="Ph. No.">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <select name="your-state" class="form-control transparent-bg" id="state-selector">
                            <option>Select State</option>
                            <option>Maharashtra</option>
                            <option>Punjab</option>
                            <option>Rajasthan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <select name="city" id="city-selector" class="form-control transparent-bg">
                            <option>Select City</option>
                            <option>option 1</option>
                            <option>option 2</option>
                            <option>option 3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <select name="reach-us" id="reach-selector" class="form-control transparent-bg">
                            <option>Reach Us For?</option>
                            <option>option 1</option>
                            <option>option 2</option>
                            <option>option 3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <button type="submit" id="footer-submit" class="btn btn-default">Send</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- Don't forget analytics -->
<script>
    function openNav() {
        document.getElementById("myNav").style.height = "100%";
    }
    function closeNav() {
        document.getElementById("myNav").style.height = "0%";
    }
    $('.carousel .vertical .item').each(function(){
        var next = $(this).next();
        if (!next.length) {
            next = $(this).siblings(':first');
        }
        next.children(':first-child').clone().appendTo($(this));

        for (var i=1;i<3;i++) {
            next=next.next();
            if (!next.length) {
                next = $(this).siblings(':first');
            }

            next.children(':first-child').clone().appendTo($(this));
        }
    });
</script>
<script src="<?php echo e(asset('themes/frontend')); ?>/js/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('themes/frontend')); ?>/js/index.js"></script>
<!-- <script src="<?php echo e(asset('themes/frontend')); ?>/js/scripts.js"></script> -->
<script src="<?php echo e(asset('themes/frontend')); ?>/js/script.js"></script>
<script src="<?php echo e(asset('themes/frontend')); ?>/js/slick.js"></script>
<!-- <script src="<?php echo e(asset('themes/frontend')); ?>/js/parallax1.js"></script> -->
<script type="text/javascript">
    $(document).ready(function(){
        $('.your-class').slick({
            autoplay: true,
            dots: true,
            arrows: false,
            slidesToShow: 2,
            responsive: [
                {
                    breakpoint:800,
                    settings:{
                        slidesToShow: 1,
                        slidesToScroll:1
                    }
                },
                {
                    breakpoint:480,
                    settings:{
                        slidesToShow:1,
                        slidesToScroll:1
                    }
                }
            ]
        });
    });

    $(document).ready(function(){
        $('.brands').slick({
            autoplay: false,
            dots: false,
            arrows: false,
            slidesToShow: 4,
            slidesToScroll:1,
            responsive: [
                {
                    breakpoint:800,
                    settings:{
                        slidesToShow: 2,
                        slidesToScroll:2
                    }
                },
                {
                    breakpoint:480,
                    settings:{
                        slidesToShow:1,
                        slidesToScroll:1
                    }
                }
            ]
        });
    });

</script>
<?php echo $__env->yieldContent('page_script'); ?>
</body>

</html>
