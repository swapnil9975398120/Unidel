<?php $__env->startSection('page_title','Force | Product Inner page'); ?>
<?php $__env->startSection('page_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <section class="product-banner">
    <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/product-inner/banner-3350-.png" alt="banner img">
    
    <div class="container">
        <div class="product-inner-caption">
            <h1>traveller school <br/>
            bus 3350</h1>
        </div>
        <div class="row">
            <div class="col-md-4 col-sm-4">
                <h3><a href="#">traveller school bus 3350</a></h3>
            </div>
            <div class="col-md-4 col-sm-4">
                <h3><a href="#">traveller school bus 3700</a></h3>
            </div>
            <div class="col-md-4 col-sm-4">
                <h3><a href="#">traveller school bus 4020</a></h3>
            </div>
        </div>
    </div>
</section>

<section class="features">
    <div class="container">
        <h1>salient features</h1>
        <div class="row">
            <div class="col-md-3 col-sm-3">
                <div class="feature-wrap">
                    <img class="img-100 img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/product-inner/feature-1.jpg">
                    <p>
                        Monocoque body structure provides total safety and car like ride quality.
                    </p>

                    <p>
                        NVH re - engineered to deliver significant reduction in noise, vibrations & harshness in the passenger area.</p>
                    <p>
                        The Traveller School Bus now comes with Anti-Lock braking
                        System (ABS) with Electronic Brake-force Distribution (EBD) for best in class safety
                    </p>
                </div>
            </div>
            <div class="col-md-3 col-sm-3">
                <div class="feature-wrap">
                    <img class="img-100 img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/product-inner/feature-2.jpg">
                    <p>Chin gaurd and grab handle.</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-3">
                <div class="feature-wrap">
                    <img class="img-100 img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/product-inner/feature-3.jpg">
                    <p>Rack for school bags.</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-3">
                <div class="feature-wrap">
                    <img class="img-100 img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/product-inner/feature-4.jpg">
                    <p>Low foot step for easy Entry and Exit.</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-3">
                <div class="feature-wrap">
                    <img class="img-100 img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/product-inner/feature-5.jpg">
                    <p>Spacious seating layout (14 seater)</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-3">
                <div class="feature-wrap">
                    <img class="img-100 img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/product-inner/feature-6.jpg">
                    <p>tional Fitments The CBT(Child Bus Tracker)</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="technical-spec">
    <div class="container">
        <h1>technical specification</h1>
        
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="technical-wraper">
                    <table>
                          <tr>
                            <th><h4>Engine</h4></th>
                            <td><h4>fm 2.2 cr</h4></td>
                          </tr>
                          <tr>
                            <th><p>Emission</p></th>
                            <td><p>BS IV</p></td>
                          </tr>
                          <tr>
                            <th><p>Type</p></th>
                            <td><p>4 Cylinder, Common Rail</p></td>
                          </tr>
                          <tr>
                            <th><p>Displacement</p></th>
                            <td><p>2149cc</p></td>
                          </tr>
                          <tr>
                            <th><p>Max power</p></th>
                            <td><p>130hp @ 3800 rpm</p></td>
                          </tr>
                          <tr>
                            <th><p>Max torque</p></th>
                            <td><p>300nm @ 1600-2400 rpm</p></td>
                          </tr>
                    </table>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="gray-bg">
                    <h4>transmission</h4>
                    <table>
                          <tr>
                            <th><p>Type</p></th>
                            <td><p>Synchromesh</p></td>
                          </tr>
                          <tr>
                            <th><p>No. of Gears</p></th>
                            <td><p>5 Forward, 1 Reverse, 5th gear Overdrive</p></td>
                          </tr>
                    </table>
                </div>
            </div>  
            <div class="col-md-3 col-sm-6">
                <div class="gray-bg">
                    <h4>axles</h4>
                    <table>
                          <tr>
                            <th><p>Front</p></th>
                            <td><p>Dead Rigid, I-Beam (Reverse Elliot Type)</p></td>
                          </tr>
                          <tr>
                            <th><p>Rear</p></th>
                            <td><p>Live Rigid</p></td>
                          </tr>
                    </table>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="gray-bg">
                    <h4>suspension</h4>
                    <table>
                          <tr>
                            <th><p>Front</p></th>
                            <td><p>Semi elliptical leaf springs with hydraulic shock absorbers and anti roll bar</p></td>
                          </tr>
                          <tr>
                            <th><p>Rear</p></th>
                            <td><p>  Semi elliptical leaf springs with  hydraulic shock absorbers</p></td>
                          </tr>
                    </table>
                </div>
            </div>  
        </div>
    </div>
</section>

<section class="product-dealer">
    <div class="container">
        <h1>dealer locator</h1>
        <div class="row">
            <div class="col-md-6 col-sm-6">
                <div class="product-dealer-wrap">
                    <h4>mahalakshmi motors</h4>
                    <p>Showroom</p>
                    <p>
                        Address : Door 6-10/3, Opp To BHPV Sub Station, Ram Nagar, BHPV Post Vizag, Andhra Pradesh 530012  Contact No: 0891-2700077
                    </p>    

                    <p>Workshop</p>
                    <p> 
                        Address : Door 6-10/3, Opp To BHPV Sub Station, Ram Nagar, BHPV Post Vizag, Andhra Pradesh 500012  Contact No: 0891-2707262/09553111171
                    </p>    
                </div>
            </div>
            <div class="col-md-6 col-sm-6">
                <div class="product-inner-form">
                    <form class="product-form-wraper">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-12">
                                    <input type="text" name="dealer-name" class="form-control transparent-bg" placeholder="Name">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <input type="email" name="dealer-email" class="form-control transparent-bg" placeholder="Email">
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <input type="text" name="dealer-phone" class="form-control transparent-bg" placeholder="Ph. No.">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <select name="your-state" class="form-control transparent-bg" id="product-state-selector">
                                        <option>Select State</option>
                                        <option>Maharashtra</option>
                                        <option>Punjab</option>
                                        <option>Rajasthan</option>
                                    </select>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <select name="your-state" class="transparent-bg form-control" id="product-state-selector">
                                        <option>Select city</option>
                                        <option>city 1</option>
                                        <option>city 2</option>
                                        <option>city 3</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group"> 
                            <button type="submit" id="product-footer-submit" class="btn btn-default">Send</button>
                        </div>
                    </form> 
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>