<?php $__env->startSection('page_title','Force | Home'); ?>
<?php $__env->startSection('page_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <section class="video-sec hidden-xs" data-parallax="scroll">
        <video width="100%" ontrols autoplay>
            <source src="<?php echo e(asset('themes/frontend')); ?>/images/home-page_ - converted with Clipchamp.mp4" type="video/mp4">
            <source src="<?php echo e(asset('themes/frontend')); ?>/images/home-page_ - converted with Clipchamp.mp4" type="video/ogg">
        </video>
        <div class="banner-text">
            <h1>Empowering<br/>India</h1>
            <p>An automotive manufacturing company that moves<br/>
                more than just cars</p>
            <a href="#">Know More</a>
        </div>
    </section>
    <section class="visible-xs mobile-video-sec">
        <img style="height: 100vh;" class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/home-mob.jpg">
    </section>

    <div class="parent-wrap">
        <section class="about-sec">
            <div class="image" data-type="background" data-speed="2"></div>
            <div class="stuff" data-type="content">
                <div class="about-wraper">
                    <h1>ABOUT</h1>
                    <div class="row">
                        <div class="col-md-3 col-sm-3 col-xs-12">
                            <p class="larger-para">
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.
                            </p>
                            <p class="smaller-para">
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.
                            </p>
                            <a href="" class="know-more">Know More</a>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="about-carosual-wrap">
                                <div id="carousel-main" class="carousel slide " data-ride="carousel" data-interval="5000">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carousel-main" data-slide-to="0" class="active">01</li>
                                        <li data-target="#carousel-main" data-slide-to="1">02</li>
                                        <li data-target="#carousel-main" data-slide-to="2">03</li>
                                        <!-- <li data-target="#carousel-main" data-slide-to="3">04</li> -->
                                    </ol>
                                    <!-- Carousel items -->
                                    <div class="carousel-inner">
                                        <div class="active item">
                                            <img src="<?php echo e(asset('themes/frontend')); ?>/images/about-01.jpg" class="img-responsive img-100">
                                        </div>
                                        <div class="item">
                                            <img src="<?php echo e(asset('themes/frontend')); ?>/images/about-02.jpg" class="img-responsive img-100">
                                        </div>
                                        <div class="item">
                                            <img src="<?php echo e(asset('themes/frontend')); ?>/images/about-03.jpg" class="img-responsive img-100">
                                        </div>
                                    <!--                                       <div class="item">
                                          <img src="<?php echo e(asset('themes/frontend')); ?>/images/about-04.jpg" class="img-responsive img-100">
                                      </div> -->
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-1">
                            <!-- Carousel items --><!-- Controls --><!-- <a class="left carousel-control" href="#carousel-pager" role="button" data-slide="prev">
                                   <span class="glyphicon glyphicon-chevron-up" aria-hidden="true"></span>
                                   <span class="sr-only">Previous</span>
                               </a>
                               <a class="right carousel-control" href="#carousel-pager" role="button" data-slide="next">
                                   <span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span>
                                   <span class="sr-only">Next</span>
                               </a> -->

                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- History Section -->
        <section class="history-section">
            <div class="image" data-type="background" data-speed="7"></div>
            <div class="stuff" data-type="content">
                <div class="history-wrap">
                    <h1>History</h1>
                    <div class="row">
                        <div class="col-xs-3 col-md-2"> <!-- required for floating -->
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs nav-stacked">
                                <li class="active"><a href="#1958" data-toggle="tab">1958</a></li>
                                <li><a href="#1978" data-toggle="tab">1978</a></li>
                                <li><a href="#1999" data-toggle="tab">1999</a></li>
                                <li><a href="#2016" data-toggle="tab">2016</a></li>
                            </ul>
                        </div>

                        <div class="col-xs-9 col-md-3">
                            <!-- Tab panes -->
                            <div class="tab-content pull-left">
                                <div class="tab-pane active" id="1958">
                                    <p>Production of Tempo 3-wheeler; 'Hanseat' started at Goregaon, Mumbai.</p>
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis.</p>
                                    <img  class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/history-border.png">
                                </div>
                                <div class="tab-pane" id="1978">
                                    <p>1978 Tab.</p>
                                    <img  class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/history-border.png">
                                </div>
                                <div class="tab-pane" id="1999">
                                    <p>1999 Tab.</p>
                                    <img  class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/history-border.png">
                                </div>
                                <div class="tab-pane" id="2016">
                                    <p>2016 Tab.</p>
                                    <img  class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/history-border.png">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
        <!-- History Section Ends-->

        <!-- Delivering Section -->
        <section>
            <div class="image" data-type="background" data-speed="6"></div>
            <div class="stuff" data-type="content">
                <div class="delivering-wraper">
                    <h1>Delivering</h1>
                    <h2>values</h2>
                    <div class="row">
                        <div class="col-md-3 col-sm-3">
                            <p class="larger-para">
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.
                            </p>
                            <p class="smaller-para">
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.
                            </p>
                        </div>
                        <div class="col-md-8 col-sm-8">
                            <div class="delivering-carousel-wrap">
                                <div id="carousel-main-delivering" class="carousel slide " data-ride="carousel" data-interval="5000">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carousel-main-delivering" data-slide-to="0" class="active">01</li>
                                        <li data-target="#carousel-main-delivering" data-slide-to="1">02</li>
                                        <li data-target="#carousel-main-delivering" data-slide-to="2">03</li>
                                        <li data-target="#carousel-main-delivering" data-slide-to="3">04</li>
                                    </ol>
                                    <!-- Carousel items -->
                                    <div class="carousel-inner">
                                        <div class="active item">
                                            <img src="<?php echo e(asset('themes/frontend')); ?>/images/delivering-1.jpg" class="img-responsive img-100">
                                        </div>
                                        <div class="item">
                                            <img src="<?php echo e(asset('themes/frontend')); ?>/images/about-04.jpg" class="img-responsive img-100">
                                        </div>
                                        <div class="item">
                                            <img src="<?php echo e(asset('themes/frontend')); ?>/images/about-03.jpg" class="img-responsive img-100">
                                        </div>
                                        <div class="item">
                                            <img src="<?php echo e(asset('themes/frontend')); ?>/images/about-04.jpg" class="img-responsive img-100">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Delivering section Ends -->


        <section class="we-believe">
            <div class="image" data-type="background" data-speed="5"></div>
            <div class="stuff" data-type="content">
                <h1>We Believe</h1>
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/abhay-firodia.jpg">
                    </div>
                    <div class="col-md-1 col-sm-1">
                        <i class="fa fa-quote-left fa-6" aria-hidden="true"></i>
                    </div>
                    <div class="col-md-5 col-sm-5">
                        <div class="abhay-text">
                            <p>Backed by the Gandhian vision of transformation at the grass-root level, Force Motors was established with a commitment to build a modern India through industrialization. It is with this belief that Force Motors has been active in developing utilitarian, low coast, mass transport vehicles for the common man for over 60 years. We strive to earn customer confidence by combining our ability to innovate through our design, engineering excellence and full spectrum of technologies, in-house. The Autorickshaw, the Tempo, the Traveller etc. stand as a corroboration of this. We take pride in our ability to help people achieve their business goals-big or small through our vehicles.</p>
                            <p>Dr. Abhay Firodia</p>
                            <p>Chairman - Force Motors Limited</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="news-wrap">
            <div class="image" data-type="background" data-speed="3"></div>
            <div class="stuff" data-type="content">
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <h1>News</h1>

                        <div class="your-class">
                            <div>
                                <img src="<?php echo e(asset('themes/frontend')); ?>/images/news-1.jpg">
                                <p>Obtained ISO 14001 EMS & OHSAS 18001    certifications for Pithampur, Chakan and Chennai plants</p>
                            </div>
                            <div><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/news-2.jpg">
                                <p>Force Motors introduces the All-New range of BSIV compliant Force Gurkha- Gurkha Xplorer and Gurkha Xpedition</p>
                            </div>
                            <div>
                                <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/news-1.jpg">
                                <p>Obtained ISO 14001 EMS & OHSAS 18001    certifications for Pithampur, Chakan and Chennai plants</p>
                            </div>
                        <!-- <div>
                     <img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/news-2.jpg">
                     <p>Obtained ISO 14001 EMS & OHSAS 18001    certifications for Pithampur, Chakan and Chennai plants</p>
                  </div> -->

                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="fanatics-wrap">
                            <h1>Force Fanatics</h1>
                            <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/force-fanatics.png">
                        </div>
                    </div>
                </div>
            </div>
        </section>


    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>