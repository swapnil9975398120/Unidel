<?php $__env->startSection('page_title','Force | Agricultural - Force Motors'); ?>
<?php $__env->startSection('page_css'); ?>
	<link href="<?php echo e(asset('themes/frontend')); ?>/css/style-other-demo.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('themes/frontend')); ?>/css/commercial-page.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('themes/frontend')); ?>/css/personal-page.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('themes/frontend')); ?>/css/agriculture-page.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="agri-banner-wrap">
		<div class="product-caption-img">
			<img class="img-responsive sky-bg" src="<?php echo e(asset('themes/frontend')); ?>/images/agri/agri-front.jpg">
			<img class="img-responsive product-img" src="<?php echo e(asset('themes/frontend')); ?>/images/agri/Tractor.png">
		</div>
		<ul>
			<li><a href="<?php echo e(url('/commercial_vehicle')); ?>" >commercial</a></li>
			<li><a href="<?php echo e(url('/agricultural_vehicle')); ?>" class="active">agriculture</a></li>
			<li><a href="<?php echo e(url('/personal_vehicle')); ?>">Personal</a></li>
		</ul>
		<h1>vehicles</h1>

	</section>


	<section class="product-section">
		<div class="container">
			<h1> Tractors</h1>
		</div>
	</section>

	<section class="product-row">
		<div class="container">
			<div class="row">


				<!-- Product 1st -->
				<div class="col-md-3 col-sm-3 col-xs-12 white-patch">
					<div id="myCarousel-product-1" class="carousel slide product-bg" data-ride="carousel">
						<!-- Indicators -->
						<ol class="carousel-indicators product-indicator">
							<li data-target="#myCarousel-product-1" data-slide-to="0" class="active"></li>
							<li data-target="#myCarousel-product-1" data-slide-to="1"></li>
							<li data-target="#myCarousel-product-1" data-slide-to="2"></li>
							<li data-target="#myCarousel-product-1" data-slide-to="3"></li>
							<li data-target="#myCarousel-product-1" data-slide-to="4"></li>
						</ol>

						<!-- Wrapper for slides -->
						<div class="carousel-inner text-center">
							<div class="item active">
								<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/agri/balwan-330.png" alt="balwan product img"></a>
								<h3>Balwan 330</h3>
								<p>4 Cylinder, Common Rail</p>
							</div>

							<div class="item">
								<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/agri/balwan-400.png" alt="balwan product img"></a>
								<h3>Balwan 400</h3>
								<p>4 Cylinder, Common Rail</p>
							</div>

							<div class="item">
								<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/agri/balwan-450.png" alt="balwan product img"></a>
								<h3>Balwan 450</h3>
								<p>4 Cylinder, Common Rail</p>
							</div>
							<div class="item">
								<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/agri/balwan-500.png" alt="balwan product img"></a>
								<h3>Balwan 500</h3>
								<p>4 Cylinder, Common Rail</p>
							</div>
							<div class="item">
								<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/agri/balwan-550.png" alt="balwan product img"></a>
								<h3>Balwan 550</h3>
								<p>4 Cylinder, Common Rail</p>
							</div>
						</div>

						<!-- Left and right controls -->
						<a class="left carousel-control hidden" href="#myCarousel-product-1" data-slide="prev">
							<span class="glyphicon glyphicon-chevron-left"></span>
							<span class="sr-only">Previous</span>
						</a>
						<a class="right carousel-control hidden" href="#myCarousel-product-1" data-slide="next">
							<span class="glyphicon glyphicon-chevron-right"></span>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>
				<!-- Product 2nd -->
				<div class="col-sm-3 col-md-3 col-xs-12  white-patch">
					<div id="myCarousel-product" class="carousel slide product-bg" data-ride="carousel">
						<!-- Indicators -->
						<ol class="carousel-indicators product-indicator">
							<li data-target="#myCarousel-product" data-slide-to="0" class="active"></li>
							<li data-target="#myCarousel-product" data-slide-to="1"></li>
						</ol>

						<!-- Wrapper for slides -->
						<div class="carousel-inner text-center">
							<div class="item active">
								<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/agri/orchard-mini.png" alt="balwan product img"></a>
								<h3>Orchard Mini</h3>
								<p>4 Cylinder, Common Rail</p>
							</div>

							<div class="item">
								<a href="#"><img class="img-responsive" src="<?php echo e(asset('themes/frontend')); ?>/images/agri/orchard-dlx.png" alt="balwan product img"></a>
								<h3>Orchard dlx</h3>
								<p>4 Cylinder, Common Rail</p>
							</div>
						</div>

						<!-- Left and right controls -->
						<a class="left carousel-control hidden" href="#myCarousel-product" data-slide="prev">
							<span class="glyphicon glyphicon-chevron-left"></span>
							<span class="sr-only">Previous</span>
						</a>
						<a class="right carousel-control hidden" href="#myCarousel-product" data-slide="next">
							<span class="glyphicon glyphicon-chevron-right"></span>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>
				<div class="col-sm-6 col-xs-6">

				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_script'); ?>
	<script type="text/javascript">
        $('#myCarousel-product').carousel({interval:false}); /*  initialized the carousel but don't start it  */
        var myInterval=false;

        $('#myCarousel-product .carousel-inner').mouseover(function() {
            var ctrl = $("#myCarousel-product .carousel-control .glyphicon-chevron-right");
            var interval=400;

            myInterval1 = setInterval(function(){
                ctrl.trigger("click");
            },interval);
        });

        $('#myCarousel-product .carousel-inner').mouseout(function(){
            clearInterval(myInterval1);
            myInterval1 = false;
        });

	</script>

	<script type="text/javascript">
        $('#myCarousel-product-1').carousel({interval:false}); /*  initialized the carousel but don't start it  */
        var myInterval2=false;

        $('#myCarousel-product-1 .carousel-inner').mouseover(function() {
            var ctrl = $("#myCarousel-product-1 .carousel-control .glyphicon-chevron-right");
            var interval=400;

            myInterval2 = setInterval(function(){
                ctrl.trigger("click");
            },interval);
        });

        $('#myCarousel-product-1 .carousel-inner').mouseout(function(){
            clearInterval(myInterval2);
            myInterval1 = false;
        });

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>