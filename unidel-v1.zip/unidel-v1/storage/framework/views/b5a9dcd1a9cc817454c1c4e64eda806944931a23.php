<?php $__env->startSection('page_title','Force | Investors'); ?>
<?php $__env->startSection('page_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="about-banner investor-banner">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4">
                <div class="about-banner-text investor-banner-text">
                    <h1>investors</h1>
                </div>  
            </div>
            <div class="col-md-8 col-sm-12">
                <div class="about-parent">
                    <img class="img-responsive " src="<?php echo e(asset('themes/frontend')); ?>/images/investors/investors-caption.jpg">
                        <div class="about-banner-text">
                            <p>The company is engaged in the manufacture of Light Commercial Vehicles, Small Commercial Vehicles, Utility Vehicles, Agricultural Tractors </p>
                            <p>& other products related to Automobile Industry such as Diesel Engines.
                            </p>
                        </div>
                </div>      
            </div>
        </div>
    </div>
</section>

<section class="director-board">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-6">
                <div class="investor-holder">
                    <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/investors/abhay-firodia.jpg">
                    <div class="investors-txt cust-investor">  
                        <h2>Dr. Abhaykumar Firodia</h2>
                        <p>Chairman</p>
                    </div>    
                </div>
            </div>
            <div class="col-md-7 colsm-6">
                <h1>board of <br/> directors</h1>
                <div class="investor-holder">
                <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/investors/prasanna-firodia.jpg">
                 <div class="investors-txt">  
                        <h2>Dr. prasanna Firodia</h2>
                        <p>Chairman</p>
                    </div> 
                </div>    
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 col-sm-6">
                <div class="investor-holder">    
                    <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/investors/sudhir-mehta.jpg">
                    <div class="investors-txt ">
                        <h2>Mr. sudhir mehta</h2>
                        <p>Director</p>
                    </div>
                </div>    
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="investor-holder">    
                    <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/investors/peatap-pawar.jpg">
                    <div class="investors-txt ">
                        <h2>mr. pratap g pawar</h2>
                        <p>Director</p>
                    </div>
                </div>    
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="investor-holder">    
                    <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/investors/paddy.jpg">
                    <div class="investors-txt ">
                        <h2>mr. s padmanabhan</h2>
                        <p>director</p>
                    </div>
                </div>    
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="investor-holder">    
                    <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/investors/vinay-kothari.jpg">
                    <div class="investors-txt ">
                        <h2>mr. vinay kothari</h2>
                        <p>director</p>
                    </div>
                </div>    
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="investor-holder">    
                    <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/investors/nitin-desai.jpg">
                    <div class="investors-txt ">
                        <h2>mr. nitin r desai</h2>
                        <p>director</p>
                    </div>
                </div>    
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="investor-holder">    
                    <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/investors/indira-parikh.jpg">
                    <div class="investors-txt ">
                        <h2>Dr. indira J parikh</h2>
                        <p>director</p>
                    </div>
                </div>    
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="investor-holder">    
                    <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/investors/arun-seth.jpg">
                    <div class="investors-txt ">
                        <h2>Mr. Arun Sheth</h2>
                        <p>director</p>
                    </div>
                </div>    
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="investor-holder">    
                    <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/investors/arvind-mahajan.jpg">
                    <div class="investors-txt ">
                        <h2>Mr. Arvind Mahajan</h2>
                        <p>director</p>
                    </div>
                </div>    
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="investor-holder">    
                    <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/investors/deosthalee.jpg">
                    <div class="investors-txt ">
                        <h2>Mr. Y. M. Deosthalee</h2>
                        <p>director</p>
                    </div>
                </div>    
            </div>
            <div class="visible-sm col-md-4 col-sm-6 white-patch">
                <div class="investor-holder margin-0">    
                    <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/investors/inamdar.jpg">
                    <div class="investors-txt ">
                        <h2>Mr. p. v. inamdar</h2>
                        <p>executive director</p>
                    </div>
                </div>  
            </div>
        </div>
    </div>
</section>

<section class="dierector-board-1 hidden-sm">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6 col-md-push-8 white-patch">
                <div class="investor-holder margin-0">    
                    <img class="img-responsive img-100" src="<?php echo e(asset('themes/frontend')); ?>/images/investors/inamdar.jpg">
                    <div class="investors-txt ">
                        <h2>Mr. p. v. inamdar</h2>
                        <p>executive director</p>
                    </div>
                </div>  
            </div>
        </div>
    </div>
</section>

<section class="financial-result">
    <div class="container">
        <h1>financial results</h1>    
  <!-- Tab panes -->
              <div class="tab-content">
                <div  role="tabpanel" class="tab-pane active row" id="01">
                    <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>    
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                </div>

                <div role="tabpanel" class="tab-pane row" id="02">
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                </div>
                <div role="tabpanel" class="tab-pane row" id="03">
                    <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                </div>
                <div role="tabpanel" class="tab-pane row" id="04">
                    <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <a href="#">
                                <div class="finance-result-wraper">
                                    <h2>30 th june, 2017</h2>
                                    <p>Unaudited Financial Results fot the Quarter Ended</p>
                                </div>
                            </a>
                        </div>
                </div>
              </div>
              <div class="clearfix"></div>
                <ul class="nav nav-tabs pull-right" role="tablist">
                    <li role="presentation" class="active"><a href="#01" aria-controls="01" role="tab" data-toggle="tab">01</a></li>
                    <li role="presentation"><a href="#02" aria-controls="02" role="tab" data-toggle="tab">02</a></li>
                    <li role="presentation"><a href="#03" aria-controls="03" role="tab" data-toggle="tab">03</a></li>
                    <li role="presentation"><a href="#04" aria-controls="04" role="tab" data-toggle="tab">04</a></li>
                </ul>
</section>

<section class="share-holder">
    <div class="container">
        <h1>shareholders information</h1>
  <!-- Nav tabs -->
        <ul class="nav nav-tabs" role="tablist">
            <li role="presentation" class="active">
                <a href="#annual-report" aria-controls="annual-report" role="tab" data-toggle="tab">Annual Report</a>
            </li>
            <li role="presentation">
                <a href="#shareholding-pattern" aria-controls="shareholding-pattern" role="tab" data-toggle="tab">Shareholding Pattern</a>
            </li>
            <li role="presentation">
                <a href="#code_of_conduct" aria-controls="code of conduct" role="tab" data-toggle="tab">Code of Conduct</a>
            </li>
            <li role="presentation">
                <a href="#unclaimed_ammount" aria-controls="unclaimed_ammount" role="tab" data-toggle="tab">Unclaimed Amount</a>
            </li>
            <li role="presentation">
                <a href="#stock_exchange" aria-controls="stock_exchange" role="tab" data-toggle="tab">Stock Exchange</a>
            </li>
            <li role="presentation">
                <a href="#other" aria-controls="other" role="tab" data-toggle="tab">Other</a>
            </li>
        </ul>

  <!-- Tab panes -->
        <div class="tab-content">
            <div role="tabpanel" class="tab-pane active row" id="annual-report">
                <div class="col-md-4 col-sm-4">
                    <a href="">
                        <div class="finance-result-wraper">
                            <h2>fy 2016-17</h2>
                            <i class="fa fa-download" aria-hidden="true"></i>
                            <p>58th Annual Report</p>
                        </div>
                    </a>        
                </div>
                <div class="col-md-4 col-sm-4">
                    <a href="">
                        <div class="finance-result-wraper">
                            <h2>fy 2016-17</h2>
                            <i class="fa fa-download" aria-hidden="true"></i>
                            <p>58th Annual Report</p>
                        </div>
                    </a>
                </div>
                <div class="col-md-4 col-sm-4">
                    <a href="">
                        <div class="finance-result-wraper">
                            <h2>fy 2016-17</h2>
                            <i class="fa fa-download" aria-hidden="true"></i>
                            <p>58th Annual Report</p>
                        </div>
                    </a>
                </div>    
            </div>
            <div role="tabpanel" class="tab-pane row" id="shareholding-pattern">
                <div class="col-md-4 col-sm-4">
                    <a href="">
                        <div class="finance-result-wraper">
                            <h2>fy 2016-17</h2>
                            <i class="fa fa-download" aria-hidden="true"></i>
                            <p>58th Annual Report</p>
                        </div>
                    </a>
                </div>
                <div class="col-md-4 col-sm-4">
                    <a href="">
                        <div class="finance-result-wraper">
                            <h2>fy 2016-17</h2>
                            <i class="fa fa-download" aria-hidden="true"></i>
                            <p>58th Annual Report</p>
                        </div>
                    </a>
                </div> 
            </div>
            <div role="tabpanel" class="tab-pane row" id="code_of_conduct">
                <div class="col-md-4 col-sm-4">
                    <a href="">
                        <div class="finance-result-wraper">
                            <h2>fy 2016-17</h2>
                            <i class="fa fa-download" aria-hidden="true"></i>
                            <p>58th Annual Report</p>
                        </div>
                    </a>
                </div>
                <div class="col-md-4 col-sm-4">
                    <a href="">
                        <div class="finance-result-wraper">
                            <h2>fy 2016-17</h2>
                            <i class="fa fa-download" aria-hidden="true"></i>
                            <p>58th Annual Report</p>
                        </div>
                    </a>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane row" id="unclaimed_ammount">
                <div class="col-md-4 col-sm-4">
                    <a href="">
                        <div class="finance-result-wraper">
                            <h2>fy 2016-17</h2>
                            <i class="fa fa-download" aria-hidden="true"></i>
                            <p>58th Annual Report</p>
                        </div>
                    </a>
                </div>
                <div class="col-md-4 col-sm-4">
                    <a href="">
                        <div class="finance-result-wraper">
                            <h2>fy 2016-17</h2>
                            <i class="fa fa-download" aria-hidden="true"></i>
                            <p>58th Annual Report</p>
                        </div>
                    </a>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane row" id="stock_exchange">
                <div class="col-md-4 col-sm-4">
                    <div class="finance-result-wraper">
                        <h2>fy 2012</h2>
                        <i class="fa fa-download" aria-hidden="true"></i>
                        <p>59th Annual Report</p>
                    </div>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane row" id="other">
                <div class="col-md-4 col-sm-4">
                    <div class="finance-result-wraper">
                        <h2>fy 2010-11</h2>
                        <i class="fa fa-download" aria-hidden="true"></i>
                        <p>59th Annual Report</p>
                    </div>
                </div>
            </div>
        </div>
      </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>