<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
 <script src="<?php echo e(asset('themes/frontend')); ?>/js/bootstrap.js"></script>
  <script src="<?php echo e(asset('themes/frontend')); ?>/js/slick.js"></script>
   <script type="text/javascript">
  
   jQuery(document).on('ready', function() {

         jQuery(".stories-slider").slick({

        dots: true,

        infinite: true,

        slidesToShow: 1,

        slidesToScroll: 1,

        autoplay: true,

        arrows : true
       

      });
          });
  
   </script>
    <script type="text/javascript">
  jQuery(document).on('ready', function() {

      $window = jQuery( window ).width();

      if($window<=767){

        jQuery(".logo-slider").slick({

        dots: false,

        infinite: true,

        slidesToShow: 1,

        slidesToScroll: 1,

        autoplay: true

      });

      }else if($window<=991){

         jQuery(".logo-slider").slick({

        dots: false,

        infinite: true,

        slidesToShow: 2,

        slidesToScroll: 2,

        autoplay: true

      });

      }else{

        jQuery(".logo-slider").slick({

        dots: false,

        infinite: false,

        slidesToShow:4,

        slidesToScroll: 4,

        autoplay: false

      });

      }

      

    });

   jQuery(document).on('ready', function() {

         jQuery(".logo-slider").slick({

        dots: false,

        infinite: true,

        slidesToShow: 4,

        slidesToScroll: 4,

        autoplay: true,

        arrows : true
       

      });
          });

   </script>
   <?php echo $__env->yieldContent('page_script'); ?>
   </body>
</html>
