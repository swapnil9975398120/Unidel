var path = document.querySelector('.path');
var length = path.getTotalLength();