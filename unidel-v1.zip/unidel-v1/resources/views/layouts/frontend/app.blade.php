@include('includes.header')

@yield('content')

@include('includes.footer')